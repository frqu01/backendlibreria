﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IExceptionApi
    {
        Exception Success(string mensajeError);
        Exception Success(string mensajeError, int statusCode);
        Exception Information(string mensajeError);
        Exception Information(string mensajeError, int statusCode);
        Exception Warning(string mensajeError);
        Exception Warning(string mensajeError, int statusCode);
        Exception Error(string mensajeError);
        Exception Error(string mensajeError, int statusCode);
    }
}
