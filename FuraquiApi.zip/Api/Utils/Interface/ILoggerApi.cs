﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface ILoggerApi
    {
        ResultadoApi Success(string contenido);
        ResultadoApi Information(string contenido);
        ResultadoApi Warning(string contenido);
        ResultadoApi Error(string contenido);
    }
}
