﻿using Api.Domains;
using Api.Utils.Enum;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IKafkaApi
    {
        void Consumer();
        void ProducerCreate(dynamic entity);
    }
}
