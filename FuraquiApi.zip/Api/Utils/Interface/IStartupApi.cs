﻿using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Api.Utils.Interface
{
    public interface IStartupApi
    {
        void Configure(IApplicationBuilder iApplicationBuilder, IHostEnvironment env);
        void ConfigureServices(IConfiguration iConfiguration, IServiceCollection iServiceCollection);
        void RequestLocalizationOptions(RequestLocalizationOptions options);
    }
}
