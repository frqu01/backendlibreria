﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IResponseApi
    {
        public ResultadoApi Success();
        public ResultadoApi Success(string mensaje, dynamic dato);
        public ResultadoApi Success(dynamic dato);
        public ResultadoApi Information();
        public ResultadoApi Information(dynamic dato);
        public ResultadoApi Information(string mensaje, dynamic dato);
        public ResultadoApi Warning();
        public ResultadoApi Warning(dynamic dato);
        public ResultadoApi Warning(string mensaje, dynamic dato);
        public ResultadoApi Error();
        public ResultadoApi Error(dynamic dato);
        public ResultadoApi Error(string mensaje, dynamic dato);
        public ResultadoApi AlreadyExist(string campo);
        public ResultadoApi AlreadyExist();
        public ResultadoApi AlreadyExist(dynamic dato);
        public ResultadoApi NotExist(string campo);
        public ResultadoApi NotExist();
        public ResultadoApi CreateOk();
        public ResultadoApi CreateOk(int id);
        public ResultadoApi CreateOk(long id);
        public ResultadoApi CreateOk(List<int> ids);
        public ResultadoApi CreateOk(List<long> ids);
        public ResultadoApi ReadOk();
        public ResultadoApi ReadOk(dynamic dato);
        public ResultadoApi ReadOk(dynamic dato, int cantidadDatos);
        public ResultadoApi ReadByIdOk(dynamic dato);
        public ResultadoApi UpdateOk();
        public ResultadoApi DeleteOk();
        public ResultadoApi ActivateOk();
        public ResultadoApi New(ResultadoApi resultadoApi);
        public ResultadoApi ErrorValidate(string campo, string mensaje);
    }
}
