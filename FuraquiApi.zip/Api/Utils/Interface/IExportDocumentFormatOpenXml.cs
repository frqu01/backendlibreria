﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IExportDocumentFormatOpenXml
    {
        ResultadoApi Word(dynamic listData, dynamic request);
    }
}
