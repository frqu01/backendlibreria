﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IFunctionApi
    {
        string DesEncriptar(string texto);
        string Encriptar(string texto);
        T AppSettingObtener<T>(string texto);
        string ConnectionStringObtener(string texto);
        string ReflexionTipoDato(dynamic obj, string NombreCampo);
        Target MapperSingle<Source, Target>(Source source);
        List<Target> MapperList<Source, Target>(List<Source> source);
        ResultadoApi Exportar(dynamic listData, dynamic request);
        ResultadoApi CorreoEnviar(CorreoApi correoApi);
    }
}
