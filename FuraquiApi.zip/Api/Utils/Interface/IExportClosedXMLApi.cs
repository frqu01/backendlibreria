﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Interface
{
    public interface IExportClosedXMLApi
    {
        ResultadoApi Excel(dynamic listData, dynamic request);
    }
}
