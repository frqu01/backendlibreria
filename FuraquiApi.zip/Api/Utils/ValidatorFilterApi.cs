﻿using Api.Domains;
using Api.Utils.Enum;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace Api.Utils
{
    public class ValidatorFilterApi : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                var errores = new List<ErrorValidacionApi>();

                EstadoSolicitudApi estadoSolicitudApi = new()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = TipoMensajeRespuestaApi.ErrorValidacion.GetString(),
                    TipoNotificacionId = TipoNotificacionApi.Warning
                };

                foreach (var modelStateKey in context.ModelState.Keys)
                {
                    var value = context.ModelState[modelStateKey];
                    foreach (var error in value.Errors)
                    {
                        ErrorValidacionApi erroresValidacionApi = new()
                        {
                            Campo = modelStateKey,
                            Mensaje = error.ErrorMessage
                        };
                        errores.Add(erroresValidacionApi);
                    }
                }

                var resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = estadoSolicitudApi,
                    ErroresValidacionApi = errores
                };

                context.Result = new JsonResult(resultadoApi)
                {
                    StatusCode = 200
                };
            }
        }
    }
}
