﻿using Api.Utils.Enum;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace Api.Utils
{
    public static class GlobalApi
    {
        public static IConfiguration IConfiguration;
        public static IHostEnvironment IHostingEnvironment;
        public static IServiceCollection IServiceCollection;
        public static IDataProtector IDataProtector;
        public static IApplicationBuilder IApplicationBuilder;
        public static TipoAmbienteProgramacionApi EnvironmentName;
        public static int CantidadRegistrosMaximo;
    }
}
