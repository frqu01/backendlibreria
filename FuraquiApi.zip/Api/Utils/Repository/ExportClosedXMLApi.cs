﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using System.Text;
using ClosedXML.Excel;

namespace Api.Utils.Repository
{
    public class ExportClosedXMLApi : IExportClosedXMLApi
    {
        public ResultadoApi Excel(dynamic listData, dynamic request)
        {
            ResultadoApi resultadoApi = new ResultadoApi();

            var primerDato = listData[0];

            string nombreArchivo = primerDato.GetType().Name
                        + DateTime.Now.ToString("yyyyMMddHHmmssfff")
                        + request.RegistroApiUsuarioId.ToString()
                        + request.RegistroApiEmpresaId.ToString()
                        + ".xlsx";

            using (MemoryStream memoryStream = new MemoryStream())
            {
                using (var wbook = new XLWorkbook())
                {
                    var sheet = wbook.Worksheets.Add("Sheet1");

                    #region Cabecera
                    int contadorCabecera = 1;
                    foreach (var item in primerDato.GetType().GetProperties())
                    {
                        sheet.Cell(1, contadorCabecera).Value = item.Name;
                        sheet.Cell(1, contadorCabecera).Style.Font.Bold = true;
                        sheet.Cell(1, contadorCabecera).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                        sheet.Cell(1, contadorCabecera).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                        sheet.Cell(1, contadorCabecera).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        sheet.Cell(1, contadorCabecera).Style.Fill.BackgroundColor = XLColor.BlueGray;
                        sheet.Cell(1, contadorCabecera).Style.Font.FontColor = XLColor.White;
                        sheet.Column(contadorCabecera).Width = 20;
                        contadorCabecera++;
                    }
                    #endregion

                    #region Cuerpo del excel
                    int recordIndex = 2;
                    foreach (var data in listData)
                    {
                        int columnIndex = 1;
                        foreach (var item in primerDato.GetType().GetProperties())
                        {
                            var value = data.GetType().GetProperty(item.Name).GetValue(data, null) ?? "";

                            sheet.Cell(recordIndex, columnIndex).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                            sheet.Cell(recordIndex, columnIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;

                            switch (TipoColumnaExportarApiExtension.GetEnumByName(item.PropertyType.Name))
                            {
                                case TipoColumnaExportarApi.String:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                                    break;
                                case TipoColumnaExportarApi.Int32:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                                    break;
                                case TipoColumnaExportarApi.Boolean:
                                    value = value == true ? "Verdadero" : "Falso";
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                                    break;
                                case TipoColumnaExportarApi.Decimal:
                                    value = value.ToString("0.##");
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                                    break;
                                case TipoColumnaExportarApi.Datetime:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                                    break;
                                case TipoColumnaExportarApi.Int64:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                                    break;
                                case TipoColumnaExportarApi.Int16:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                                    break;
                                case TipoColumnaExportarApi.Double:
                                    value = value.ToString("0.##");
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                                    break;
                                default:
                                    sheet.Cell(recordIndex, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                                    break;
                            }

                            sheet.Cell(recordIndex, columnIndex).Value = value;

                            columnIndex++;
                        }
                        recordIndex++;
                    }
                    #endregion

                    wbook.SaveAs(memoryStream);
                    memoryStream.Position = 0;

                    resultadoApi = new ResultadoApi()
                    {
                        EstadoSolicitudApi = new EstadoSolicitudApi()
                        {
                            EstaCorrecto = true,
                            TipoNotificacionId = TipoNotificacionApi.Success,
                            MensajeRespuesta = "Exportado correctamente."
                        },
                        DatosApi = new ExportarArchivoApi()
                        {
                            Contenido = memoryStream.ToArray(),
                            Nombre = nombreArchivo,
                            Tipo = TipoReporteExportarApi.Excel.GetString()
                        }
                    };
                }
            }

            return resultadoApi;
        }

        public void Test()
        {
            TipoExtensionArchivoApi a = TipoExtensionArchivoApi._323;
            a.GetContentType();
        }
    }
}
