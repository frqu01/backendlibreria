﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Kernel.Geom;
using iText.Layout.Properties;
using iText.Layout.Element;
using iText.Kernel.Colors;
using System.Text;

namespace Api.Utils.Repository
{
    public class ExportITextApi : IExportITextApi
    {
        public ResultadoApi Pdf(dynamic listData, dynamic request)
        {
            ResultadoApi resultadoApi = new ResultadoApi();

            var primerDato = listData[0];

            string nombreArchivo = primerDato.GetType().Name
                        + DateTime.Now.ToString("yyyyMMddHHmmssfff")
                        + request.RegistroApiUsuarioId.ToString()
                        + request.RegistroApiEmpresaId.ToString()
                        + ".pdf";

            using (MemoryStream memoryStream = new MemoryStream())
            {
                PdfWriter pdfWriter = new PdfWriter(memoryStream);
                pdfWriter.SetCloseStream(false);
                PdfDocument pdfDocument = new PdfDocument(pdfWriter);
                Document document = new Document(pdfDocument, PageSize.A4.Rotate());

                #region Cabecera
                int contadorCabecera = 0;

                foreach (var item in primerDato.GetType().GetProperties())
                {
                    contadorCabecera++;
                }
                Table tablaGrilla = new Table(UnitValue.CreatePercentArray(contadorCabecera)).UseAllAvailableWidth();

                foreach (var item in primerDato.GetType().GetProperties())
                {
                    Cell cell = new Cell()
                    .SetBackgroundColor(new DeviceGray(0.75f))
                    .Add(new Paragraph(item.Name))
                    .SetTextAlignment(TextAlignment.CENTER);
                    tablaGrilla.AddCell(cell);
                }
                #endregion

                #region Cuerpo del pdf
                foreach (var data in listData)
                {
                    foreach (var item in primerDato.GetType().GetProperties())
                    {
                        var value = data.GetType().GetProperty(item.Name).GetValue(data, null) ?? "";
                        var textAlignment = new TextAlignment();

                        switch (TipoColumnaExportarApiExtension.GetEnumByName(item.PropertyType.Name))
                        {
                            case TipoColumnaExportarApi.String:
                                textAlignment = TextAlignment.LEFT;
                                break;
                            case TipoColumnaExportarApi.Int32:
                                textAlignment = TextAlignment.RIGHT;
                                break;
                            case TipoColumnaExportarApi.Boolean:
                                value = value == true ? "Verdadero" : "Falso";
                                textAlignment = TextAlignment.CENTER;
                                break;
                            case TipoColumnaExportarApi.Decimal:
                                value = value.ToString("0.##");
                                textAlignment = TextAlignment.RIGHT;
                                break;
                            case TipoColumnaExportarApi.Datetime:
                                textAlignment = TextAlignment.CENTER;
                                break;
                            case TipoColumnaExportarApi.Int64:
                                textAlignment = TextAlignment.RIGHT;
                                break;
                            case TipoColumnaExportarApi.Int16:
                                textAlignment = TextAlignment.RIGHT;
                                break;
                            case TipoColumnaExportarApi.Double:
                                value = value.ToString("0.##");
                                textAlignment = TextAlignment.RIGHT;
                                break;
                            default:
                                textAlignment = TextAlignment.LEFT;
                                break;
                        }

                        Cell cell = new Cell()
                        .Add(new Paragraph(value.ToString()))
                        .SetTextAlignment(textAlignment);
                        tablaGrilla.AddCell(cell);
                    }
                }
                #endregion

                document.Add(tablaGrilla);
                document.Close();

                byte[] exportBinary = memoryStream.ToArray();
                memoryStream.Write(exportBinary, 0, exportBinary.Length);
                memoryStream.Position = 0;

                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = true,
                        TipoNotificacionId = TipoNotificacionApi.Success,
                        MensajeRespuesta = "Exportado correctamente."
                    },
                    DatosApi = new ExportarArchivoApi()
                    {
                        Contenido = exportBinary,
                        Nombre = nombreArchivo,
                        Tipo = TipoReporteExportarApi.Pdf.GetString()
                    }
                };
            }

            return resultadoApi;
        }
    }
}
