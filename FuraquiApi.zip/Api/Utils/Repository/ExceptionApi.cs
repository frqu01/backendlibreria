﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class ExceptionApi : IExceptionApi
    {
        private static Exception Exception(string mensajeError, TipoNotificacionApi tipoNotificacionId, int statusCode)
        {
            Exception excepcion = new(mensajeError);

            if (statusCode != 0)
            {
                excepcion.Data["StatusCode"] = statusCode;
            }

            excepcion.Data["ResultadoApi"] = new ResultadoApi()
            {
                EstadoSolicitudApi = new EstadoSolicitudApi()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = mensajeError,
                    TipoNotificacionId = tipoNotificacionId
                }
            };
            return excepcion;
        }
        public Exception Error(string mensajeError)
        {
            return Exception(mensajeError, TipoNotificacionApi.Error, 0);
        }

        public Exception Error(string mensajeError, int statusCode)
        {
            return Exception(mensajeError, TipoNotificacionApi.Error, statusCode);
        }

        public Exception Information(string mensajeError)
        {
            return Exception(mensajeError, TipoNotificacionApi.Information, 0);
        }

        public Exception Information(string mensajeError, int statusCode)
        {
            return Exception(mensajeError, TipoNotificacionApi.Information, statusCode);
        }

        public Exception Success(string mensajeError)
        {
            return Exception(mensajeError, TipoNotificacionApi.Success, 0);
        }

        public Exception Success(string mensajeError, int statusCode)
        {
            return Exception(mensajeError, TipoNotificacionApi.Success, statusCode);
        }

        public Exception Warning(string mensajeError)
        {
            return Exception(mensajeError, TipoNotificacionApi.Warning, 0);
        }

        public Exception Warning(string mensajeError, int statusCode)
        {
            return Exception(mensajeError, TipoNotificacionApi.Warning, statusCode);
        }
    }
}
