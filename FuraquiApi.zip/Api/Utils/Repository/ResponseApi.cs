﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Azure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class ResponseApi : IResponseApi
    {
        public ResultadoApi Success()
        {
            return RespuestaEstado(TipoNotificacionApi.Success.GetString(), null, TipoNotificacionApi.Success);
        }
        public ResultadoApi Success(string mensaje, dynamic dato)
        {
            return RespuestaEstado(mensaje, dato, TipoNotificacionApi.Success);
        }
        public ResultadoApi Success(dynamic dato)
        {
            return dato is string ? RespuestaEstado((string)dato, null, TipoNotificacionApi.Success) : RespuestaEstado(TipoNotificacionApi.Success.GetString(), dato, TipoNotificacionApi.Success);
        }
        public ResultadoApi Information()
        {
            return RespuestaEstado(TipoNotificacionApi.Information.GetString(), null, TipoNotificacionApi.Information);
        }
        public ResultadoApi Information(dynamic dato)
        {
            return dato is string ?  RespuestaEstado((string)dato, null, TipoNotificacionApi.Information) : RespuestaEstado(TipoNotificacionApi.Information.GetString(), dato, TipoNotificacionApi.Information);
        }
        public ResultadoApi Information(string mensaje, dynamic dato)
        {
            return RespuestaEstado(mensaje, dato, TipoNotificacionApi.Information);
        }
        public ResultadoApi Warning()
        {
            return RespuestaEstado(TipoNotificacionApi.Warning.GetString(), null, TipoNotificacionApi.Warning);
        }
        public ResultadoApi Warning(dynamic dato)
        {
            return dato is string ? RespuestaEstado((string)dato, null, TipoNotificacionApi.Warning) : RespuestaEstado(TipoNotificacionApi.Warning.GetString(), dato, TipoNotificacionApi.Warning);
        }
        public ResultadoApi Warning(string mensaje, dynamic dato)
        {
            return RespuestaEstado(mensaje, dato, TipoNotificacionApi.Warning);
        }
        public ResultadoApi Error()
        {
            return RespuestaEstado(TipoNotificacionApi.Error.GetString(), null, TipoNotificacionApi.Error);
        }
        public ResultadoApi Error(dynamic dato)
        {
            return dato is string ? RespuestaEstado((string)dato, null, TipoNotificacionApi.Error) : RespuestaEstado(TipoNotificacionApi.Error.GetString(), dato, TipoNotificacionApi.Error);
        }
        public ResultadoApi Error(string mensaje, dynamic dato)
        {
            return RespuestaEstado(mensaje, dato, TipoNotificacionApi.Error);
        }
        private ResultadoApi RespuestaEstado(string mensaje, dynamic dato, TipoNotificacionApi tipoNotificacionApi)
        {
            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = tipoNotificacionApi switch
                    {
                        TipoNotificacionApi.Success => true,
                        TipoNotificacionApi.Information => true,
                        TipoNotificacionApi.Warning => false,
                        TipoNotificacionApi.Error => false,
                        _ => true
                    },
                    MensajeRespuesta = mensaje,
                    TipoNotificacionId = tipoNotificacionApi
                },
                DatosApi = dato
            };
        }
        public ResultadoApi AlreadyExist(string campo)
        {
            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = string.Format(TipoMensajeRespuestaApi.RegistroYaExiste.GetString(), campo),
                    TipoNotificacionId = TipoNotificacionApi.Warning
                }
            };
        }
        public ResultadoApi AlreadyExist()
        {
            return AlreadyExist("Registro");
        }
        public ResultadoApi CreateOk()
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.CreadoCorrectamente);
        }
        public ResultadoApi ReadOk()
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ListadoCorrectamente);
        }
        public ResultadoApi ReadOk(dynamic dato)
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ListadoCorrectamente, dato);
        }
        public ResultadoApi ReadOk(dynamic dato, int cantidadDatos)
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ListadoCorrectamente,dato,cantidadDatos);
        }
        public ResultadoApi UpdateOk()
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ActualizadoCorrectamente);
        }
        public ResultadoApi DeleteOk()
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.EliminadoCorrectamente);
        }
        public ResultadoApi ActivateOk()
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ActivadoCorrectamente);
        }
        private ResultadoApi RespuestaCorrecta(TipoMensajeRespuestaApi tipoMensajeRespuestaApi)
        {
            return RespuestaCorrecta(tipoMensajeRespuestaApi, null, null);
        }
        private ResultadoApi RespuestaCorrecta(TipoMensajeRespuestaApi tipoMensajeRespuestaApi, dynamic dato)
        {
            return RespuestaCorrecta(tipoMensajeRespuestaApi, dato, null);
        }
        private ResultadoApi RespuestaCorrecta(TipoMensajeRespuestaApi tipoMensajeRespuestaApi, dynamic dato, int? cantidadDatos)
        {
            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = true,
                    MensajeRespuesta = tipoMensajeRespuestaApi.GetString(),
                    TipoNotificacionId = TipoNotificacionApi.Success,
                    CantidadDatos = cantidadDatos
                },
                DatosApi = dato
            };
        }
        public ResultadoApi New(ResultadoApi resultadoApi)
        {
            return resultadoApi;
        }
        public ResultadoApi ErrorValidate(string campo, string mensaje)
        {
            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = true,
                    MensajeRespuesta = TipoMensajeRespuestaApi.ErrorValidacion.GetString(),
                    TipoNotificacionId = TipoNotificacionApi.Warning
                },
                ErroresValidacionApi = new()
                {
                    new ErrorValidacionApi()
                    {
                        Campo = campo,
                        Mensaje = mensaje
                    }
                }
            };
        }
        public ResultadoApi ReadByIdOk(dynamic dato)
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.ListadoCorrectamente, dato);
        }

        public ResultadoApi NotExist(string campo)
        {
            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = string.Format(TipoMensajeRespuestaApi.NoExiste.GetString(), campo),
                    TipoNotificacionId = TipoNotificacionApi.Warning
                }
            };
        }
        public ResultadoApi NotExist()
        {
            return NotExist("Registro");
        }
        public ResultadoApi CreateOk(int id)
        {
            var idResponse = new
            {
                Id = id
            };
            return RespuestaCorrecta(TipoMensajeRespuestaApi.CreadoCorrectamente, idResponse);
        }
        public ResultadoApi CreateOk(long id)
        {
            var idResponse = new
            {
                Id = id
            };
            return RespuestaCorrecta(TipoMensajeRespuestaApi.CreadoCorrectamente, idResponse);
        }
        public ResultadoApi CreateOk(List<int> ids)
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.CreadoCorrectamente, ids);
        }
        public ResultadoApi CreateOk(List<long> ids)
        {
            return RespuestaCorrecta(TipoMensajeRespuestaApi.CreadoCorrectamente, ids);
        }
        public ResultadoApi AlreadyExist(dynamic dato)
        {
            if(dato is string)
            {
                return AlreadyExist((string) dato);
            }

            return new ResultadoApi()
            {
                EstadoSolicitudApi = new()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = string.Format(TipoMensajeRespuestaApi.RegistroYaExiste.GetString(), "La lista"),
                    TipoNotificacionId = TipoNotificacionApi.Warning
                },
                DatosApi = dato
            };
        }
    }
}
