﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Azure;
using Azure.Core;
using Confluent.Kafka;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class KafkaApi : IKafkaApi
    {
        protected readonly ProducerConfig _producerConfig;
        protected readonly ConsumerConfig _consumerConfig;
        protected readonly ILoggerApi _iLoggerApi;
        //protected readonly IKafkaPersonaApi _iKafkaPersonaApi;
        //protected readonly IKafkaAlcanceApi _iKafkaAlcanceApi;
        public KafkaApi(ProducerConfig producerConfig, 
            ConsumerConfig consumerConfig,
            ILoggerApi iLoggerApi)
        {
            _producerConfig = producerConfig;
            _consumerConfig = consumerConfig;
            _iLoggerApi = iLoggerApi;
            //_iKafkaPersonaApi = iKafkaPersonaApi;
            //_iKafkaAlcanceApi = iKafkaAlcanceApi;
        }

        private async Task Producer(KafkaSolicitudApi kafkaSolicitudApi)
        {
            using (var producer = new ProducerBuilder<Null,string>(_producerConfig).Build())
            {
                await producer.ProduceAsync(kafkaSolicitudApi.TipoKafkaTopicApi.GetString(), new Message<Null, string> { Value = JsonConvert.SerializeObject(kafkaSolicitudApi) });
                producer.Flush(TimeSpan.FromSeconds(10));
            }
        }

        public void Consumer()
        {
            var tipoKafkaTopicApiList = System.Enum.GetValues(typeof(TipoKafkaTopicApi)).Cast<TipoKafkaTopicApi>().ToList();

            foreach (var tipoKafkaTopicApi in tipoKafkaTopicApiList)
            {
                Task.Run(() =>
                {
                    Consumer(tipoKafkaTopicApi);
                });
            }
        }

        private void Consumer(TipoKafkaTopicApi tipoKafkaTopicApi)
        {
            using (var consumer = new ConsumerBuilder<Null, string>(_consumerConfig).Build())
            {
                consumer.Subscribe(tipoKafkaTopicApi.GetString());

                while (true)
                {
                    var cr = consumer.Consume();
                    //ConsumerUpdate(cr.Message.Value);
                    _iLoggerApi.Success(tipoKafkaTopicApi.GetString() + ": " + cr.Message.Value);
                    Console.WriteLine(cr.Message.Value);
                }
            }
        }

        public void ProducerCreate(dynamic entity)
        {
            var entityName = entity.GetType().Name;
            #region Registro en Kafka
            var tipoKafkaTopicApi = entityName switch
            {
                "Alcance" => TipoKafkaTopicApi.Alcance,
                "Usuario" => TipoKafkaTopicApi.Usuario,
                "Persona" => TipoKafkaTopicApi.Persona,
                _ => TipoKafkaTopicApi.Ninguno
            };

            if (tipoKafkaTopicApi != TipoKafkaTopicApi.Ninguno)
            {
                var tipoKafkaEventoApi = TipoKafkaEventoApi.Create;
                var request = new KafkaSolicitudApi()
                {
                    KafkaSolicitudApiId = Guid.NewGuid(),
                    TipoKafkaEventoApi = tipoKafkaEventoApi,
                    TipoKafkaTopicApi = tipoKafkaTopicApi,
                    Entidad = JsonConvert.SerializeObject(entity)
                };

                Task.Run(() =>
                {
                    _ = Producer(request);
                });
            }
            #endregion
        }

        //public void Producer(ChangeTracker changeTracker)
        //{
        //    if (changeTracker.AutoDetectChangesEnabled)
        //    {
        //        var modifiedEntities = changeTracker.Entries().Where(x => x.State == EntityState.Added ||
        //                                                                  x.State == EntityState.Modified ||
        //                                                                  x.State == EntityState.Deleted).ToList();

        //        foreach (var entity in modifiedEntities)
        //        {
        //            var entidad = entity.Entity;
        //            var entityName = entity.Entity.GetType().Name;
        //            #region Registro en Kafka
        //            var tipoKafkaTopicApi = entityName switch
        //            {
        //                "Alcance" => TipoKafkaTopicApi.Alcance,
        //                "Usuario" => TipoKafkaTopicApi.Usuario,
        //                "Persona" => TipoKafkaTopicApi.Persona,
        //                _ => TipoKafkaTopicApi.Ninguno
        //            };

        //            if (tipoKafkaTopicApi != TipoKafkaTopicApi.Ninguno)
        //            {
        //                var tipoKafkaEventoApi = entity.State switch
        //                {
        //                    EntityState.Added => TipoKafkaEventoApi.Create,
        //                    EntityState.Deleted => ActivateDelete(entity),
        //                    _ => TipoKafkaEventoApi.Update
        //                };
        //                var request = new KafkaSolicitudApi()
        //                {
        //                    KafkaSolicitudApiId = Guid.NewGuid(),
        //                    TipoKafkaEventoApi = tipoKafkaEventoApi,
        //                    TipoKafkaTopicApi = tipoKafkaTopicApi,
        //                    Entidad = entidad
        //                };

        //                Task.Run(() =>
        //                {
        //                    _ = Producer(request);
        //                });
        //            }
        //            entity.State = entity.State == EntityState.Deleted ? entity.State = EntityState.Modified : entity.State;
        //            #endregion
        //        }
        //    }
        //}

        private TipoKafkaEventoApi ActivateDelete(EntityEntry entityEntry)
        {
            return bool.Parse(entityEntry.CurrentValues["RegistroApiEstado"].ToString()) == true ? TipoKafkaEventoApi.Activate : TipoKafkaEventoApi.Delete;
        }
        //private void ConsumerUpdate(string tramaKafka)
        //{
        //    var kafkaSolicitudApi = JsonConvert.DeserializeObject<KafkaSolicitudApi>(tramaKafka);

//            switch (kafkaSolicitudApi.TipoKafkaEventoApi)
//            {
//                case TipoKafkaEventoApi.Create:
//                    switch (kafkaSolicitudApi.TipoKafkaTopicApi)
//                    {
//                        case TipoKafkaTopicApi.Alcance:
//                            _iKafkaAlcanceApi.Crear(kafkaSolicitudApi.Entidad);
//                            break;
//                        case TipoKafkaTopicApi.Usuario:
//                            break;
//                        case TipoKafkaTopicApi.Persona:
//                            _iKafkaPersonaApi.Crear(kafkaSolicitudApi.Entidad);
//                            break;
//                        default:
//                            break;
//                    }
//                    break;
//                case TipoKafkaEventoApi.Update:
//                    switch (kafkaSolicitudApi.TipoKafkaTopicApi)
//                    {
//                        case TipoKafkaTopicApi.Alcance:
//                            _iKafkaAlcanceApi.Actualizar(kafkaSolicitudApi.Entidad);
//                            break;
//                        case TipoKafkaTopicApi.Usuario:
//                            break;
//                        case TipoKafkaTopicApi.Persona:
//                            _iKafkaPersonaApi.Actualizar(kafkaSolicitudApi.Entidad);
//                            break;
//                        default:
//                            break;
//                    }
//break;
//default:
//                    break;
//            }
        //}
    }
}
