﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class ConsumeRestApi : IConsumeRestApi
    {
        private IResponseApi _iResponseApi;
        public ConsumeRestApi(IResponseApi iResponseApi)
        {
            _iResponseApi = iResponseApi;
        }
        public async Task<ResultadoApi> FormUrlEncoded(SolicitudServicioApi solicitudServicioApi)
        {
            return await ConsumeService(solicitudServicioApi, TipoSolicitudCuerpoRestApi.FormUrlEncoded);
        }

        public async Task<ResultadoApi> Json(SolicitudServicioApi solicitudServicioApi)
        {
            return await ConsumeService(solicitudServicioApi, TipoSolicitudCuerpoRestApi.Json);
        }
        private async Task<ResultadoApi> ConsumeService(SolicitudServicioApi solicitudServicioApi, TipoSolicitudCuerpoRestApi tipoSolicitudCuerpoRestApi)
        {
            var resultadoApi = _iResponseApi.Success("Consultado correctamente.");
            string url = solicitudServicioApi.HostUrl.ToLower() + solicitudServicioApi.MetodoUrl.ToLower();
            string response = string.Empty;

            if (TipoSolicitudCuerpoRestApi.FormUrlEncoded == tipoSolicitudCuerpoRestApi)
            {
                HttpClientHandler clientHandler = new HttpClientHandler();

                clientHandler.ServerCertificateCustomValidationCallback += (sender, certificate, chain, errors) =>
                {
                    if (GlobalApi.EnvironmentName == TipoAmbienteProgramacionApi.Desarrollo) return true;
                    return errors == SslPolicyErrors.None;
                };
                HttpClient client = new HttpClient(clientHandler);

                var req = new HttpRequestMessage(HttpMethod.Post, url) { Content = new FormUrlEncodedContent(solicitudServicioApi.Entidad) };
                response = await client.SendAsync(req).Result.Content.ReadAsStringAsync();
            }

            if (TipoSolicitudCuerpoRestApi.Json == tipoSolicitudCuerpoRestApi)
            {
                HttpContent httpContent = new StringContent(solicitudServicioApi.Entidad, Encoding.UTF8, TipoSolicitudCuerpoRestApi.Json.GetString());

                HttpResponseMessage httpResponseMessage = new();

                HttpClient client = new();
                client.DefaultRequestHeaders.Accept.Clear();
                //client.DefaultRequestHeaders.Add("Origin", "testQa");
                client.DefaultRequestHeaders.Add("Accept-Language", "es-PE");

                if(solicitudServicioApi.TipoMetodoRest == HttpMethod.Post)
                {
                    httpResponseMessage = await client.PostAsync(url, httpContent);
                }

                if (solicitudServicioApi.TipoMetodoRest == HttpMethod.Get)
                {
                    httpResponseMessage = await client.GetAsync(url);
                }

                if (solicitudServicioApi.TipoMetodoRest == HttpMethod.Put)
                {
                    httpResponseMessage = await client.PutAsync(url, httpContent);
                }

                if (solicitudServicioApi.TipoMetodoRest == HttpMethod.Patch) 
                {
                    httpResponseMessage = await client.PatchAsync(url, httpContent);
                }

                if (solicitudServicioApi.TipoMetodoRest == HttpMethod.Delete) 
                {
                    httpResponseMessage = await client.DeleteAsync(url);
                }

                response = await httpResponseMessage.Content.ReadAsStringAsync();
            }

            resultadoApi.DatosApi = response;

            if (solicitudServicioApi.EsResultadoApi)
            {
                resultadoApi = JsonConvert.DeserializeObject<ResultadoApi>(response);
            }

            return resultadoApi;
        }
    }
}
