﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Newtonsoft.Json;
using OpenIddict.Server;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static OpenIddict.Server.OpenIddictServerEvents;
using static System.Net.Mime.MediaTypeNames;

namespace Api.Utils.Repository
{
    public class HandlerExceptionApi : IHandlerExceptionApi
    {
        private readonly ILoggerApi _iLoggerApi;

        public HandlerExceptionApi()
        {
            _iLoggerApi = new LoggerApi();
        }
        //Errores controlados
        public async Task HandlerExceptionApplication(HttpContext context)
        {
            ResultadoApi resultadoApi = new ResultadoApi();
            string contenido = string.Empty;
            string detalle = string.Empty;
            string mensaje = string.Empty; 

            context.Response.StatusCode = StatusCodes.Status500InternalServerError;
            context.Response.ContentType = Text.Plain;

            var ex = context.Features.Get<IExceptionHandlerPathFeature>();

            if (ex != null)
            {
                mensaje = ex.Error.Message == null ? (ex.Error.InnerException == null ? "" : ex.Error.InnerException.Message) : ex.Error.Message + (ex.Error.InnerException == null ? "" : " " + ex.Error.InnerException.Message);

                if (ex.Error.Data["ResultadoApi"] != null)
                {
                    resultadoApi = ex.Error.Data["ResultadoApi"] as ResultadoApi;
                    ex.Error.Data["ResultadoApi"] = null;
                }
                else
                {
                    resultadoApi = new ResultadoApi()
                    {
                        EstadoSolicitudApi = new EstadoSolicitudApi()
                        {
                            EstaCorrecto = false,
                            MensajeRespuesta = ex.Error.Message == null ? "" : ex.Error.Message, //TipoMensajeApi.ExcepcionNoControlada.GetString() + ,
                            MensajeRespuestaDetalle = ex.Error.InnerException == null ? null : ex.Error.InnerException.Message,
                            TipoNotificacionId = TipoNotificacionApi.Error
                        }
                    };
                }

                if (ex.Error.Data["StatusCode"] != null)
                {
                    context.Response.StatusCode = (int)ex.Error.Data["StatusCode"];
                }

                contenido = mensaje + $" :: [StatusCode] :: {context.Response.StatusCode} :: [Tracer] :: {ex.Error.StackTrace}";
                _iLoggerApi.Error(contenido);
            }
            else
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        MensajeRespuesta = TipoMensajeApi.ExcepcionNoControlada.GetString(),
                        TipoNotificacionId = TipoNotificacionApi.Error
                    }
                };

                contenido = ex.Error.Message == null ? TipoMensajeApi.ExcepcionNoControlada.GetString() : ex.Error.Message + $" :: [StatusCode] :: 500 :: [Tracer] :: No se pudo obtener el detalle del error";
                _iLoggerApi.Error(contenido);
            }

            context.Response.ContentType = "application/json";

            await context.Response.WriteAsync(JsonConvert.SerializeObject(resultadoApi, Formatting.None,
                            new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore
                            })).ConfigureAwait(false);
        }
        //Errores de carga en el servidor
        public async Task HandlerExceptionServer(StatusCodeContext context)
        {
            ResultadoApi resultadoApi = new ResultadoApi();

            var ex = context.HttpContext.Features.Get<IExceptionHandlerPathFeature>();

            if (!context.HttpContext.Response.ContentLength.HasValue || context.HttpContext.Response.ContentLength == 0)
            {
                resultadoApi.EstadoSolicitudApi = new EstadoSolicitudApi()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = "Código: " + context.HttpContext.Response.StatusCode.ToString() + ". " + ((HttpStatusCode)context.HttpContext.Response.StatusCode).ToString() + ". Url: " + context.HttpContext.Request.Path,
                    TipoNotificacionId = TipoNotificacionApi.Error
                };
            }
            else
            {
                resultadoApi.EstadoSolicitudApi = new EstadoSolicitudApi()
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = "Código: 500 - Error en el servidor.",
                    TipoNotificacionId = TipoNotificacionApi.Error
                };
            }

            context.HttpContext.Response.ContentType = "application/json";
            await context.HttpContext.Response.WriteAsync(JsonConvert.SerializeObject(resultadoApi, Formatting.None,
                            new JsonSerializerSettings
                            {
                                NullValueHandling = NullValueHandling.Ignore
                            }));
        }
        public void ExceptionSaveRegistroApi(ChangeTracker changeTracker)
        {
            var errores = new List<ErrorValidacionApi>();
            int count = 1;
            long registroEmpresaId = 0;
            long registroApiUsuarioId = 0;

            if (changeTracker.Entries().Count() > 0)
            {
                foreach (var item in changeTracker.Entries())
                {
                    var nameEntity = item.Entity.GetType().Name;

                    if (item.Entity.GetType().GetProperty("RegistroApiEmpresaId") == null ||
                        long.Parse(item.Entity.GetType().GetProperty("RegistroApiEmpresaId").GetValue(item.Entity, null).ToString()) == 0)
                    {
                        if(registroEmpresaId != 0)
                        {
                            item.Entity.GetType().GetProperty("RegistroApiEmpresaId").SetValue(item.Entity, registroEmpresaId);
                        }
                        else
                        {
                            errores.Add(new ErrorValidacionApi()
                            {
                                Entidad = nameEntity,
                                Campo = "RegistroApiEmpresaId",
                                Mensaje = "'RegistroApiEmpresaId' no debería estar vacío."
                            });
                        }
                    }
                    else {
                        registroEmpresaId = long.Parse(item.Entity.GetType().GetProperty("RegistroApiEmpresaId").GetValue(item.Entity, null).ToString());
                    }


                    if (item.Entity.GetType().GetProperty("RegistroApiUsuarioId") == null ||
                        long.Parse(item.Entity.GetType().GetProperty("RegistroApiUsuarioId").GetValue(item.Entity, null).ToString()) == 0)
                    {
                        if (registroApiUsuarioId != 0) 
                        {
                            item.Entity.GetType().GetProperty("RegistroApiUsuarioId").SetValue(item.Entity, registroApiUsuarioId);
                        } else
                        {
                            errores.Add(new ErrorValidacionApi()
                            {
                                Entidad = nameEntity,
                                Campo = "RegistroApiUsuarioId",
                                Mensaje = "'RegistroApiUsuarioId' no debería estar vacío."
                            });
                        }
                    } else
                    {
                        registroApiUsuarioId = long.Parse(item.Entity.GetType().GetProperty("RegistroApiUsuarioId").GetValue(item.Entity, null).ToString());
                    }

                    count++;
                }

                if (errores.Count > 0)
                {
                    Exception exception = new Exception();

                    var resultadoApi = new ResultadoApi()
                    {
                        EstadoSolicitudApi = new EstadoSolicitudApi()
                        {
                            EstaCorrecto = false,
                            MensajeRespuesta = "Se encontraron errores de validación.",
                            TipoNotificacionId = TipoNotificacionApi.Warning
                        },
                        ErroresValidacionApi = errores
                    };

                    exception.Data["ResultadoApi"] = resultadoApi;
                    exception.Data["StatusCode"] = 200;

                    throw exception;
                }
            }
        }
    }
}
