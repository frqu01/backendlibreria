﻿using Api.Domains;
using Api.Utils.Interface;
using Microsoft.AspNetCore.Http;
using OpenIddict.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static OpenIddict.Server.OpenIddictServerEvents;

namespace Api.Utils.Repository
{
    public class OpenIddictServerHandlerApi : IOpenIddictServerHandler<ApplyTokenResponseContext>
    {
        private readonly IExceptionApi _exceptionApi;
        public OpenIddictServerHandlerApi(IExceptionApi exceptionApi)
        {
            _exceptionApi = exceptionApi;
        }
        public ValueTask HandleAsync(ApplyTokenResponseContext context)
        {
            //Se envía a la librería que capta los errores
            if (context.Error != null)
            {
                throw _exceptionApi.Error(context.Response.ErrorDescription + " - " + context.Response.ErrorUri, StatusCodes.Status401Unauthorized);
            }
            else
            {
                return default;
            }
        }
    }
}
