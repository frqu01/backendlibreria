﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using AutoMapper;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.StaticFiles;
using Microsoft.Extensions.Configuration;
using System.Net;
using System.Net.Mail;

namespace Api.Utils.Repository
{
    public class FunctionApi : IFunctionApi
    {
        public T AppSettingObtener<T>(string texto)
        {
            return GlobalApi.IConfiguration.GetValue<T>(texto);
        }

        public string ConnectionStringObtener(string texto)
        {
            return GlobalApi.IConfiguration.GetConnectionString(texto);
        }

        public string Encriptar(string texto)
        {
            return texto == null ? null : GlobalApi.IDataProtector.Protect(texto);
        }

        public string DesEncriptar(string texto)
        {
            return texto == null ? null : GlobalApi.IDataProtector.Unprotect(texto);
        }

        public string ReflexionTipoDato(dynamic obj, string NombreCampo)
        {
            string tipoDato = null;
            if (obj.GetType().GetProperty(NombreCampo) == null)
            {
                foreach (var propiedad in obj.GetType().GetProperties())
                {
                    var clase = obj.GetType().GetProperty(propiedad.Name).GetValue(obj, null);
                    if (clase != null && clase.GetType().GetProperty(NombreCampo) != null)
                    {
                        tipoDato = clase.GetType().GetProperty(NombreCampo).GetValue(clase, null).GetType().Name;
                    }
                }
            }
            else
            {
                if (obj.GetType().GetProperty(NombreCampo).GetValue(obj, null) != null)
                {
                    tipoDato = obj.GetType().GetProperty(NombreCampo).GetValue(obj, null).GetType().Name;
                }
            }

            return tipoDato;
        }

        public Target MapperSingle<Source, Target>(Source source)
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap<Source, Target>());
            return new Mapper(config).Map<Target>(source);
        }

        public List<Target> MapperList<Source, Target>(List<Source> source)
        {
            var config = new MapperConfiguration(cfg => cfg.CreateMap<Source, Target>());
            return new Mapper(config).Map<List<Target>>(source);
        }

        public ResultadoApi Exportar(dynamic listData, dynamic request)
        {
            ResultadoApi resultadoApi = new ResultadoApi();

            if (!listData.GetType().IsSerializable)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Error,
                        MensajeRespuesta = "No se envió una lista de datos."
                    }
                };
            }

            if (listData.Count < 1)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Error,
                        MensajeRespuesta = "No se encontraron registros para exportar."
                    }
                };
            }

            IExportITextApi iExportITexApi = new ExportITextApi();
            IExportClosedXMLApi iExportClosedXMLApi = new ExportClosedXMLApi();
            IExportDocumentFormatOpenXml iExportDocumentFormatOpenXml = new ExportDocumentFormatOpenXml();

            switch (request.ReporteTipoId)
            {
                case TipoReporteExportarApi.Pdf:
                    resultadoApi = iExportITexApi.Pdf(listData, request);
                    break;
                case TipoReporteExportarApi.Excel:
                    resultadoApi = iExportClosedXMLApi.Excel(listData, request);
                    break;
                case TipoReporteExportarApi.Word:
                    resultadoApi = iExportDocumentFormatOpenXml.Word(listData, request);
                    break;
                default:
                    break;
            }

            return resultadoApi;
        }

        public ResultadoApi CorreoEnviar(CorreoApi correoApi)
        {
            //var filePath = "D:\\Documentos\\Frank\\Trabajos\\MDP\\Clonfluence - PAGDES-200522-2131.pdf";
            //var provider = new FileExtensionContentTypeProvider();
            //if (!provider.TryGetContentType(filePath, out var contentType))
            //{
            //    contentType = "application/octet-stream";
            //}
            var resultadoApi = new ResultadoApi();

            if (correoApi == null)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió los datos del correo."
                    }
                };
            };

            if(correoApi.Emisor == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el emisor."
                    }
                };
            }

            if (correoApi.Receptor == null || correoApi.Receptor.Count < 1)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el receptor."
                    }
                };
            }

            if (correoApi.Cuerpo == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el cuerpo."
                    }
                };
            }

            var smtp = new SmtpClient();
            var message = new MailMessage();

            smtp = new SmtpClient
            {
                Host = "smtp.live.com",
                Port = 587,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(correoApi.Emisor, correoApi.Contrasena)
            };

            foreach (var item in correoApi.Receptor)
            {
                message = new MailMessage(correoApi.Emisor, item);
            }

            foreach (var item in correoApi.Respuesta)
            {
                message.ReplyToList.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CopiaOculta)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CorreoAdjuntoApi)
            {
                var filePath = "D:\\Documentos\\Frank\\Trabajos\\MDP\\Clonfluence - PAGDES-200522-2131.pdf";
                var provider = new FileExtensionContentTypeProvider();
                
                if (!provider.TryGetContentType(filePath, out var contentType))
                {
                    contentType = "application/octet-stream";
                }

                //message.Attachments.Add(new Attachment(item.MemoryStream, item.Nombre, item.TipoArchivoDescripcion));
            }

            message.IsBodyHtml = true;
            message.Body = correoApi.Cuerpo;

            return resultadoApi;
        }
    }
}
