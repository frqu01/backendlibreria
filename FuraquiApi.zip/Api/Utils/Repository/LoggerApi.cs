﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class LoggerApi : ILoggerApi
    {
        protected readonly IFunctionApi _iFunctionApi = new FunctionApi();
        private ResultadoApi Log(string contenido, TipoLoggerNotificacionApi tipoLogger)
        {
            ResultadoApi resultadoApi = new();

            string tipoLoggerNotificacion = tipoLogger.GetString();

            contenido = $"[" + DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss") + $"] :: [{tipoLoggerNotificacion}] :: [Mensaje]: " + contenido;

            //Validar que se haya enviado la dirección del logger
            if (_iFunctionApi.AppSettingObtener<string>("Logger:Directorio") == null || _iFunctionApi.AppSettingObtener<string>("Logger:Directorio") == "")
            {
                resultadoApi.EstadoSolicitudApi = new EstadoSolicitudApi
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = "No se envió el valor de la variable 'Directorio' en la llave 'Logger'.",
                    TipoNotificacionId = TipoNotificacionApi.Warning
                };

                return resultadoApi;
            }
            //Validar que se haya enviado el tipo del logger
            if (_iFunctionApi.AppSettingObtener<string>("Logger:TipoMostrado") == null || _iFunctionApi.AppSettingObtener<string>("Logger:TipoMostrado") == "")
            {
                resultadoApi.EstadoSolicitudApi = new EstadoSolicitudApi
                {
                    EstaCorrecto = false,
                    MensajeRespuesta = "No se envió el valor de la variable 'Tipo' en la llave 'Logger'.",
                    TipoNotificacionId = TipoNotificacionApi.Warning
                };

                return resultadoApi;
            }

            //Guardar log
            if (_iFunctionApi.AppSettingObtener<string>("Logger:TipoMostrado") == TipoLoggerMostradoApi.Console.GetString())
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.WriteLine(contenido);
                Console.ReadLine();
            }
            else
            {
                string directorio = _iFunctionApi.AppSettingObtener<string>("Logger:Directorio") + $"\\Api-" + _iFunctionApi.AppSettingObtener<string>("Application:Id") + "\\";
                string nombre = DateTime.Now.ToString("yyyy-MM-dd") + $"-Api-" + _iFunctionApi.AppSettingObtener<string>("Application:Id") + ".log.txt";
                string directorioCompleto = directorio + nombre;

                if (GlobalApi.IHostingEnvironment.IsDevelopment())
                {
                    if (!Directory.Exists(directorio))
                    {
                        Directory.CreateDirectory(directorio);
                    }
                    if (!File.Exists(directorioCompleto))
                    {
                        using FileStream fs = File.Create(directorioCompleto);
                        using StreamWriter writer = new(fs, Encoding.UTF8);
                        writer.Write(contenido + Environment.NewLine);
                    }
                    else
                    {
                        using StreamWriter writer = File.AppendText(directorioCompleto);
                        writer.WriteLine(contenido);
                    }
                }
                else
                {
                    //Guardar en un servidor
                }
            }

            resultadoApi.EstadoSolicitudApi = new EstadoSolicitudApi()
            {
                EstaCorrecto = true,
                MensajeRespuesta = "Logg creado correctamente.",
                TipoNotificacionId = TipoNotificacionApi.Success
            };

            return resultadoApi;
        }
        public ResultadoApi Error(string contenido)
        {
            return Log(contenido, TipoLoggerNotificacionApi.Error);
        }

        public ResultadoApi Information(string contenido)
        {
            return Log(contenido, TipoLoggerNotificacionApi.Information);
        }

        public ResultadoApi Success(string contenido)
        {
            return Log(contenido, TipoLoggerNotificacionApi.Success);
        }

        public ResultadoApi Warning(string contenido)
        {
            return Log(contenido, TipoLoggerNotificacionApi.Warning);
        }
    }
}
