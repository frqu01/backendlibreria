﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using DocumentFormat.OpenXml;
using System.Text;
using ClosedXML.Excel;

namespace Api.Utils.Repository
{
    public class ExportDocumentFormatOpenXml : IExportDocumentFormatOpenXml
    {
        public ResultadoApi Word(dynamic listData, dynamic request)
        {
            ResultadoApi resultadoApi = new ResultadoApi();

            var primerDato = listData[0];

            string nombreArchivo = primerDato.GetType().Name
                        + DateTime.Now.ToString("yyyyMMddHHmmssfff")
                        + request.RegistroApiUsuarioId.ToString()
                        + request.RegistroApiEmpresaId.ToString()
                        + ".docx";

            using (var memoryStream = new MemoryStream())
            {
                using (WordprocessingDocument wordDocument = WordprocessingDocument.Create(memoryStream, WordprocessingDocumentType.Document, true))
                {
                    //Documento y cuerpo
                    MainDocumentPart mainPart = wordDocument.AddMainDocumentPart();
                    mainPart.Document = new Document();
                    Body body = mainPart.Document.AppendChild(new Body());

                    OrientacionHorizontal(body);

                    Table table = new Table();
                    TablaDimension(table);

                    #region Cabecera
                    TableRow tr1 = new TableRow();
                    foreach (var item in primerDato.GetType().GetProperties())
                    {
                        TableCell tableCell = new TableCell();
                        Paragraph paragraph = new Paragraph();
                        Run run = new Run();
                        RunProperties runProperties = new RunProperties();
                        ParagraphProperties paragraphProperties = new ParagraphProperties();
                        paragraphProperties.Justification = new Justification() { Val = JustificationValues.Center };
                        CeldaBorde(tableCell);

                        paragraph.Append(paragraphProperties);
                        runProperties.Bold = new Bold();
                        run.Append(runProperties);
                        run.Append(new Text(item.Name));
                        paragraph.Append(run);
                        tableCell.Append(paragraph);

                        tr1.Append(tableCell);
                    }
                    table.Append(tr1);
                    #endregion

                    #region Cuerpo del word
                    foreach (var data in listData)
                    {
                        TableRow tableRow = new TableRow();

                        foreach (var item in primerDato.GetType().GetProperties())
                        {
                            var value = data.GetType().GetProperty(item.Name).GetValue(data, null) ?? "";

                            TableCell tableCell = new TableCell();
                            Paragraph paragraph = new Paragraph();
                            Run run = new Run();
                            RunProperties runProperties = new RunProperties();
                            ParagraphProperties paragraphProperties = new ParagraphProperties();

                            CeldaBorde(tableCell);

                            switch (TipoColumnaExportarApiExtension.GetEnumByName(item.PropertyType.Name))
                            {
                                case TipoColumnaExportarApi.String:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Left };
                                    break;
                                case TipoColumnaExportarApi.Int32:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Right };
                                    break;
                                case TipoColumnaExportarApi.Boolean:
                                    value = value == true ? "Verdadero" : "Falso";
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Center };
                                    break;
                                case TipoColumnaExportarApi.Decimal:
                                    value = value.ToString("0.##");
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Right };
                                    break;
                                case TipoColumnaExportarApi.Datetime:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Center };
                                    break;
                                case TipoColumnaExportarApi.Int64:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Right };
                                    break;
                                case TipoColumnaExportarApi.Int16:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Right };
                                    break;
                                case TipoColumnaExportarApi.Double:
                                    value = value.ToString("0.##");
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Right };
                                    break;
                                default:
                                    paragraphProperties.Justification = new Justification() { Val = JustificationValues.Left };
                                    break;
                            }

                            paragraph.Append(paragraphProperties);
                            run.Append(runProperties);
                            run.Append(new Text(value.ToString()));
                            paragraph.Append(run);
                            tableCell.Append(paragraph);

                            tableRow.Append(tableCell);
                        }
                        table.Append(tableRow);
                    }
                    #endregion

                    body.Append(table);

                    mainPart.Document.Save();
                    wordDocument.Close();

                    memoryStream.Seek(0, SeekOrigin.Begin);

                    using (MemoryStream memoryStreamAux = new MemoryStream())
                    {
                        memoryStream.CopyTo(memoryStreamAux);
                        byte[] exportWord = memoryStreamAux.ToArray();

                        resultadoApi = new ResultadoApi()
                        {
                            EstadoSolicitudApi = new EstadoSolicitudApi()
                            {
                                EstaCorrecto = true,
                                TipoNotificacionId = TipoNotificacionApi.Success,
                                MensajeRespuesta = "Exportado correctamente."
                            },
                            DatosApi = new ExportarArchivoApi()
                            {
                                Contenido = exportWord,
                                Nombre = nombreArchivo,
                                Tipo = TipoReporteExportarApi.Word.GetString()
                            }
                        };
                    }
                }
            }

            return resultadoApi;
        }

        private void Cabecera()
        {
            Paragraph paragraph = new Paragraph();
            Run run = new Run();
            RunProperties runProperties = new RunProperties()
            {
                Bold = new Bold(),
                FontSize = new FontSize()
                {
                    Val = new StringValue("32")
                }
            };
            ParagraphProperties paragraphProperties = new ParagraphProperties()
            {
                Justification = new Justification()
                {
                    Val = JustificationValues.Center
                }
            };
        }

        private void OrientacionHorizontal(Body body)
        {
            SectionProperties sectionProperties = new SectionProperties();
            PageSize pageSize = new PageSize() { Width = 16838U, Height = 11906U, Orient = PageOrientationValues.Landscape };
            sectionProperties.Append(pageSize);
            body.Append(sectionProperties);
        }

        private void OrientacionVertical(Body body)
        {
            SectionProperties sectionProperties = new SectionProperties();
            PageSize pageSize = new PageSize() { Width = 16838U, Height = 11906U, Orient = PageOrientationValues.Portrait };
            sectionProperties.Append(pageSize);
            body.Append(sectionProperties);
        }

        private void TablaDimension(Table table)
        {
            TableProperties tableProperties = new TableProperties();
            TableWidth tableWidth = new TableWidth() { Width = "5000", Type = TableWidthUnitValues.Pct };
            TableStyle tableStyle = new TableStyle() { Val = "TableGrid" };

            tableProperties.Append(tableStyle, tableWidth);
            table.Append(tableProperties);
        }

        private void CeldaBorde(TableCell tableCell)
        {
            TableCellProperties tableCellProperties = new TableCellProperties();
            TableCellBorders tableCellBorders = new TableCellBorders();
            LeftBorder leftBorder = new LeftBorder() { Color = "000000", Val = new EnumValue<BorderValues>() { Value = BorderValues.Thick } };
            RightBorder rightBorder = new RightBorder() { Color = "000000", Val = new EnumValue<BorderValues>() { Value = BorderValues.Thick } };
            TopBorder topBorder = new TopBorder() { Color = "000000", Val = new EnumValue<BorderValues>() { Value = BorderValues.Thick } };
            BottomBorder bottomBorder = new BottomBorder() { Color = "000000", Val = new EnumValue<BorderValues>() { Value = BorderValues.Thick } };

            tableCellBorders.Append(leftBorder);
            tableCellBorders.Append(rightBorder);
            tableCellBorders.Append(topBorder);
            tableCellBorders.Append(bottomBorder);
            tableCellProperties.Append(tableCellBorders);
            tableCell.Append(tableCellProperties);
        }
    }
}
