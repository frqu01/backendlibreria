﻿using Api.Infrastructures;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Confluent.Kafka;
using FluentValidation;
using FluentValidation.AspNetCore;
using MicroElements.Swashbuckle.FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.DataProtection;
using Microsoft.AspNetCore.Localization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.OpenApi.Models;
using System.Globalization;
using System.Reflection;
using System.Text;

namespace Api.Utils.Repository
{
    public class StartupApi : IStartupApi
    {
        protected readonly IFunctionApi _iFunctionApi = new FunctionApi();
        public void Configure(IApplicationBuilder iApplicationBuilder, IHostEnvironment env)
        {
            GlobalApi.IApplicationBuilder = iApplicationBuilder;
            GlobalApi.IHostingEnvironment = env;


            if (env.IsDevelopment())
            {
                GlobalApi.EnvironmentName = TipoAmbienteProgramacionApi.Desarrollo;
            }
            if (env.IsProduction())
            {
                GlobalApi.EnvironmentName = TipoAmbienteProgramacionApi.Produccion;
            }
            if (env.IsStaging())
            {
                GlobalApi.EnvironmentName = TipoAmbienteProgramacionApi.Testing;
            }

            SwaggerConfigure(iApplicationBuilder);
        }

        private void AddDataProtection(IConfiguration iConfiguration, IServiceCollection iServiceCollection)
        {
            iServiceCollection.AddDataProtection()
                .PersistKeysToFileSystem(new DirectoryInfo(iConfiguration.GetValue<string>("DataProtection:Path")))
                .SetApplicationName(iConfiguration.GetValue<string>("DataProtection:ApplicationName"));

            GlobalApi.IDataProtector = iServiceCollection.BuildServiceProvider().GetRequiredService<IDataProtectionProvider>().CreateProtector(iConfiguration.GetValue<string>("DataProtection:EncryptKey"));
        }

        public void ConfigureServices(IConfiguration iConfiguration, IServiceCollection iServiceCollection)
        {
            GlobalApi.IConfiguration = iConfiguration;
            GlobalApi.IServiceCollection = iServiceCollection;
            GlobalApi.CantidadRegistrosMaximo = iConfiguration.GetValue<int>("Paginacion:CantidadRegistrosMaximo");

            //Agregar Encriptador
            AddDataProtection(iConfiguration, iServiceCollection);
            //Agregar swagger
            SwaggerConfigureServices(iConfiguration, iServiceCollection);
            //Injecciones importantes
            CommonInjection(iServiceCollection);
            //Fluent Validation
            AddFluentValidation(iServiceCollection);
            //Kafka
            KafkaInjection(iConfiguration, iServiceCollection);
        }

        private static void SwaggerConfigureServices(IConfiguration iConfiguration, IServiceCollection iServiceCollection)
        {
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            iServiceCollection.AddEndpointsApiExplorer();
            iServiceCollection.AddSwaggerGen(options =>
            {
                //Documentación
                options.SwaggerDoc("service", new OpenApiInfo
                {
                    Version = iConfiguration.GetValue<string>("Application:Version"),
                    Title = iConfiguration.GetValue<string>("Application:Name"),
                    Description = iConfiguration.GetValue<string>("Application:Description"),
                    TermsOfService = new Uri("https://www.linkedin.com/in/frank-ernesto-quiroz-gil-9279a662/"),
                    Contact = new OpenApiContact
                    {
                        Name = "Frank Quiroz Gil",
                        Email = "ing_fquirozg@hotmail.com",
                        Url = new Uri("https://www.linkedin.com/in/frank-ernesto-quiroz-gil-9279a662/")
                    },
                    License = new OpenApiLicense()
                    {
                        Name = "Frank Quiroz",
                        Url = new Uri("https://www.linkedin.com/in/frank-ernesto-quiroz-gil-9279a662/")
                    }
                });
                //Cabecera Bearer
                options.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header usando esquema Bearer. Ingresa 'Bearer' [espacio] y luego tu token en la caja de texto de abajo. Ejemplo: 'Bearer 12345abcdef'",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });
                options.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                        new OpenApiSecurityScheme
                        {
                            Reference = new OpenApiReference
                            {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                            },
                            Scheme = "oauth2",
                            Name = "Bearer",
                            In = ParameterLocation.Header,

                        },
                        new List<string>()
                    }
                });
            });
            iServiceCollection.AddFluentValidationRulesToSwagger();
        }

        private void SwaggerConfigure(IApplicationBuilder iApplicationBuilder)
        {
            iApplicationBuilder.UseSwagger(c =>
            {
                c.RouteTemplate = "swagger/{documentName}/aplicacionid" + _iFunctionApi.AppSettingObtener<string>("Application:Id") + ".json";
            });
            iApplicationBuilder.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/service/aplicacionid" + _iFunctionApi.AppSettingObtener<string>("Application:Id") + ".json", "Swagger Service");
            });
        }

        public void RequestLocalizationOptions(RequestLocalizationOptions options)
        {
            var supportedCultures = new[]
                {
                    new CultureInfo(TipoIdiomaAplicacionApi.InglesUs.GetString()),
                    new CultureInfo(TipoIdiomaAplicacionApi.EspanolPe.GetString())
                };
            options.DefaultRequestCulture = new RequestCulture(TipoIdiomaAplicacionApi.EspanolPe.GetString());
            options.SupportedCultures = supportedCultures;
            options.SupportedUICultures = supportedCultures;
        }

        private void AddFluentValidation(IServiceCollection iServiceCollection)
        {
            iServiceCollection.AddFluentValidationAutoValidation();
            iServiceCollection.AddFluentValidationClientsideAdapters();
            iServiceCollection.AddValidatorsFromAssembly(Assembly.Load("Applications"));
        }

        private static void CommonInjection(IServiceCollection iServiceCollection)
        {
            iServiceCollection.AddTransient<IExceptionApi, ExceptionApi>();
            iServiceCollection.AddTransient<ILoggerApi, LoggerApi>();
            iServiceCollection.AddTransient<IFunctionApi, FunctionApi>();
            iServiceCollection.AddTransient<IDbContextApi, DbContextApi>();
            iServiceCollection.AddTransient<IResponseApi, ResponseApi>();
            iServiceCollection.AddTransient<IConsumeRestApi, ConsumeRestApi>();
            iServiceCollection.AddTransient<IKafkaApi, KafkaApi>();
            iServiceCollection.AddTransient<IExportITextApi, ExportITextApi>();
            iServiceCollection.AddTransient<IExportClosedXMLApi, ExportClosedXMLApi>();
            iServiceCollection.AddTransient<IEmailSendApi, EmailSendApi>();
        }

        private static void KafkaInjection(IConfiguration iConfiguration, IServiceCollection iServiceCollection)
        {
            var producerConfig = new ProducerConfig()
            {
                BootstrapServers = iConfiguration.GetValue<string>("Kafka:Producer:BootstrapServers")
            };
            //iConfiguration.Bind("Kafka:Producer", producerConfig); //tiene que decir: bootstrapservers

            var consumerConfig = new ConsumerConfig
            {
                GroupId = "aplicacionid" + iConfiguration.GetValue<string>("Application:Id") + "consumer",
                BootstrapServers = iConfiguration.GetValue<string>("Kafka:Producer:BootstrapServers")
            };

            iServiceCollection.AddSingleton<ProducerConfig>(producerConfig);
            iServiceCollection.AddSingleton<ConsumerConfig>(consumerConfig);
        }
    }
}
