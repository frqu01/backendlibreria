﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Microsoft.AspNetCore.StaticFiles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Repository
{
    public class EmailSendApi : IEmailSendApi
    {
        public ResultadoApi Gmail(CorreoApi correoApi)
        {
            ResultadoApi resultadoApi;

            if (correoApi == null)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió los datos del correo."
                    }
                };

                return resultadoApi;
            };

            if (correoApi.Emisor == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el emisor."
                    }
                };

                return resultadoApi;
            }

            if (correoApi.Receptor == null || correoApi.Receptor.Count < 1)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el receptor."
                    }
                };

                return resultadoApi;
            }

            if (correoApi.Cuerpo == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el cuerpo."
                    }
                };

                return resultadoApi;
            }

            var message = new MailMessage();

            SmtpClient smtp = new SmtpClient()
            {
                Host = TipoCorreoHostApi.Outlook.GetHost(),
                Port = TipoCorreoHostApi.Outlook.GetPort(),
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(correoApi.Emisor, correoApi.Contrasena)
            };

            foreach (var item in correoApi.Receptor)
            {
                message = new MailMessage(correoApi.Emisor, item);
            }

            foreach (var item in correoApi.Respuesta)
            {
                message.ReplyToList.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CopiaOculta)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CorreoAdjuntoApi)
            {
                //var filePath = "D:\\Documentos\\Frank\\Trabajos\\MDP\\Clonfluence - PAGDES-200522-2131.pdf";
                //var provider = new FileExtensionContentTypeProvider();

                //if (!provider.TryGetContentType(filePath, out var contentType))
                //{
                //    contentType = "application/octet-stream";
                //}

                message.Attachments.Add(new Attachment(item.AdjuntoStream, item.Nombre, item.TipoExtensionArchivo.GetContentType()));
            }

            message.IsBodyHtml = true;
            message.Body = correoApi.Cuerpo;
            smtp.Send(message);

            resultadoApi = new ResultadoApi()
            {
                EstadoSolicitudApi = new EstadoSolicitudApi()
                {
                    EstaCorrecto = true,
                    TipoNotificacionId = TipoNotificacionApi.Success,
                    MensajeRespuesta = "Correo enviado correctamente."
                }
            };

            return resultadoApi;
        }

        public ResultadoApi Outlook(CorreoApi correoApi)
        {
            ResultadoApi resultadoApi;

            if (correoApi == null)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió los datos del correo."
                    }
                };

                return resultadoApi;
            };

            if (correoApi.Emisor == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el emisor."
                    }
                };

                return resultadoApi;
            }

            if (correoApi.Receptor == null || correoApi.Receptor.Count < 1)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el receptor."
                    }
                };

                return resultadoApi;
            }

            if (correoApi.Cuerpo == string.Empty)
            {
                resultadoApi = new ResultadoApi()
                {
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = false,
                        TipoNotificacionId = TipoNotificacionApi.Warning,
                        MensajeRespuesta = "No se envió el cuerpo."
                    }
                };

                return resultadoApi;
            }

            var message = new MailMessage();

            SmtpClient smtp = new SmtpClient()
            {
                Host = TipoCorreoHostApi.Gmail.GetHost(),
                Port = TipoCorreoHostApi.Gmail.GetPort(),
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                UseDefaultCredentials = false,
                Credentials = new NetworkCredential(correoApi.Emisor, correoApi.Contrasena)
            };

            foreach (var item in correoApi.Receptor)
            {
                message = new MailMessage(correoApi.Emisor, item);
            }

            foreach (var item in correoApi.Respuesta)
            {
                message.ReplyToList.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.Copia)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CopiaOculta)
            {
                message.CC.Add(item);
            }

            foreach (var item in correoApi.CorreoAdjuntoApi)
            {
                message.Attachments.Add(new Attachment(item.AdjuntoStream, item.Nombre, item.TipoExtensionArchivo.GetContentType()));
            }

            message.IsBodyHtml = true;
            message.Body = correoApi.Cuerpo;
            smtp.Send(message);

            resultadoApi = new ResultadoApi()
            {
                EstadoSolicitudApi = new EstadoSolicitudApi()
                {
                    EstaCorrecto = true,
                    TipoNotificacionId = TipoNotificacionApi.Success,
                    MensajeRespuesta = "Correo enviado correctamente."
                }
            };

            return resultadoApi;
        }
    }
}
