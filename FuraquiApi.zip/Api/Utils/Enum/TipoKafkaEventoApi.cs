﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoKafkaEventoApi
    {
        Create = 1,
        Update = 2,
        Delete = 3,
        Activate = 4
    }
}
