﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoMensajeRespuestaApi
    {
        CreadoCorrectamente = 1,
        ListadoCorrectamente = 2,
        ActualizadoCorrectamente = 3,
        EliminadoCorrectamente = 4,
        ActivadoCorrectamente = 5,
        RegistroYaExiste = 6,
        ErrorValidacion = 7,
        NoExiste = 8
    }
    public static class TipoMensajeRespuestaApiExtension
    {
        public static string GetString(this TipoMensajeRespuestaApi _enum)
        {
            return _enum switch
            {
                TipoMensajeRespuestaApi.CreadoCorrectamente => "Creado Correctamente.",
                TipoMensajeRespuestaApi.ListadoCorrectamente => "Listado Correctamente.",
                TipoMensajeRespuestaApi.ActualizadoCorrectamente => "Actualizado Correctamente.",
                TipoMensajeRespuestaApi.EliminadoCorrectamente => "Eliminado Correctamente.",
                TipoMensajeRespuestaApi.ActivadoCorrectamente => "Activado Correctamente.",
                TipoMensajeRespuestaApi.RegistroYaExiste => "{0} ya existe.",
                TipoMensajeRespuestaApi.ErrorValidacion => "Se encontraron errores de validación.",
                TipoMensajeRespuestaApi.NoExiste => "{0} no existe.",
                _ => "No Válido",
            };
        }
    }
}
