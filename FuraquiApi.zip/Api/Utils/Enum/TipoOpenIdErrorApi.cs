﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoOpenIdErrorApi
    {
        OpenIdNotRetrieved = 1,
        GrantNotImplemented = 2,
        ClientNotFound = 3
    }
    public static class TipoErrorOpenIdApiExtension
    {
        public static string GetString(this TipoOpenIdErrorApi _enum)
        {
            return _enum switch
            {
                TipoOpenIdErrorApi.OpenIdNotRetrieved => "No se pudo recuperar OpenId'.",
                TipoOpenIdErrorApi.GrantNotImplemented => "Grant no implementado.",
                TipoOpenIdErrorApi.ClientNotFound => "Cliente OpenId no encontrado.",
                _ => "No Válido",
            };
        }
    }
}
