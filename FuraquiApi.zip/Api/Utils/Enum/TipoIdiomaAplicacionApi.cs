﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoIdiomaAplicacionApi
    {
        InglesUs = 1,
        EspanolPe = 2
    }
    public static class TipoIdiomaAplicacionApiExtension
    {
        public static string GetString(this TipoIdiomaAplicacionApi _enum)
        {
            return _enum switch
            {
                TipoIdiomaAplicacionApi.InglesUs => "en-us",
                TipoIdiomaAplicacionApi.EspanolPe => "es-pe",
                _ => "No Válido",
            };
        }
    }
}
