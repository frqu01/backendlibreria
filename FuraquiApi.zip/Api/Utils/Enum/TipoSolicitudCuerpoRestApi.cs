﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoSolicitudCuerpoRestApi
    {
        Json = 1,
        FormUrlEncoded = 2
    }

    public static class TipoRequestCuerpoApiExtension
    {
        public static string GetString(this TipoSolicitudCuerpoRestApi _enum)
        {
            return _enum switch
            {
                TipoSolicitudCuerpoRestApi.Json => TipoExtensionArchivoApi._Json.GetContentType(),
                TipoSolicitudCuerpoRestApi.FormUrlEncoded => TipoExtensionArchivoApi._FormUrlEncoded.GetContentType(),
                _ => "No Válido",
            };
        }
    }
}
