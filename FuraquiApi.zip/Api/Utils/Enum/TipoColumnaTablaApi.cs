﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoColumnaTablaApi
    {
        Int16 = 1,
        Int32 = 2,
        Int64 = 3,
        Boolean = 4,
        Char = 5,
        Date = 6,
        DateTime = 7,
        Decimal = 8,
        Double = 9,
        Float = 10,
        Money = 11,
        NChar = 12,
        NText = 13,
        Numeric = 14,   
        NVarchar = 15,
        Text = 16,
        Time = 17,
        TimeStamp = 18,
        Varchar = 19,
        DateTime2 = 20
    }

    public static class TipoColumnaTablaApiExtension
    {
        public static string GetString(this TipoColumnaTablaApi _enum)
        {
            return _enum switch
            {
                TipoColumnaTablaApi.Int16 => "smallint", //short
                TipoColumnaTablaApi.Int32 => "int", //int
                TipoColumnaTablaApi.Int64 => "bigint", //long
                TipoColumnaTablaApi.Boolean => "bit", //bool
                TipoColumnaTablaApi.Varchar => GetString(_enum, 100),
                TipoColumnaTablaApi.Char => GetString(_enum, 10),
                TipoColumnaTablaApi.NVarchar => GetString(_enum, 100),
                TipoColumnaTablaApi.NChar => GetString(_enum, 10),
                TipoColumnaTablaApi.Date => "date",
                TipoColumnaTablaApi.DateTime => "datetime",
                TipoColumnaTablaApi.Decimal => GetString(_enum, 18, 2),
                TipoColumnaTablaApi.Numeric => GetString(_enum, 18, 2),
                TipoColumnaTablaApi.Double => "float",
                TipoColumnaTablaApi.Float => "float",
                TipoColumnaTablaApi.Money => "money",
                TipoColumnaTablaApi.NText => "ntext",
                TipoColumnaTablaApi.Text => "text",
                TipoColumnaTablaApi.Time => "time",
                TipoColumnaTablaApi.TimeStamp => "timestamp",
                TipoColumnaTablaApi.DateTime2 => "datetime2",
                _ => "No Válido",
            };
        }

        public static string GetString(this TipoColumnaTablaApi _enum, int lenght)
        {
            return _enum switch
            {
                TipoColumnaTablaApi.Char => $"char({lenght})",
                TipoColumnaTablaApi.NChar => $"nchar({lenght})",
                TipoColumnaTablaApi.NVarchar => $"nvarchar({lenght})",
                TipoColumnaTablaApi.Varchar => $"varchar({lenght})",
                _ => _enum.GetString(),
            };
        }
        public static string GetString(this TipoColumnaTablaApi _enum, int lenghtInteger, int lenghtDecimal)
        {
            return _enum switch
            {
                TipoColumnaTablaApi.Decimal => $"decimal({lenghtInteger},{lenghtDecimal})",
                TipoColumnaTablaApi.Numeric => $"numeric({lenghtInteger},{lenghtDecimal})",
                _ => _enum.GetString(),
            };
        }
    }
}
