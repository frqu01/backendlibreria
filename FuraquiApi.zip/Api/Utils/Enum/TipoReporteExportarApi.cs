﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoReporteExportarApi
    {
        Pdf = 1,
        Excel = 2,
        Word = 3
    }
    public static class TipoReporteExportarApiExtension
    {
        public static string GetString(this TipoReporteExportarApi _enum)
        {
            return _enum switch
            {
                TipoReporteExportarApi.Pdf => TipoExtensionArchivoApi._Pdf.GetContentType(),
                TipoReporteExportarApi.Excel => TipoExtensionArchivoApi._Xlsx.GetContentType(),
                TipoReporteExportarApi.Word => TipoExtensionArchivoApi._Docx.GetContentType(),
                _ => TipoExtensionArchivoApi._Ocx.GetContentType(),
            };
        }
    }
}
