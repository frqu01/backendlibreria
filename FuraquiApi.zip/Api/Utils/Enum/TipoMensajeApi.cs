﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoMensajeApi
    {
        LoggerSinDirectorio = 1,
        LoggerSinTipoMostrado = 2,
        LoggerOk = 3,
        ExcepcionNoControlada = 4,
        ErrorSwagger = 5
    }
    public static class TipoMensajeApiExtension
    {
        public static string GetString(this TipoMensajeApi _enum)
        {
            return _enum switch
            {
                TipoMensajeApi.LoggerSinDirectorio => "No se envió el valor de la variable 'Directorio' en la llave 'Logger'.",
                TipoMensajeApi.LoggerSinTipoMostrado => "No se envió el valor de la variable 'TipoMostrado' en la llave 'Logger'.",
                TipoMensajeApi.LoggerOk => "Logger creado correctamente.",
                TipoMensajeApi.ExcepcionNoControlada => "Ocurrió un error interno dentro de la aplicación.",
                TipoMensajeApi.ErrorSwagger => "Error interno al cargar Swagger.",
                _ => "No Válido",
            };
        }
    }
}
