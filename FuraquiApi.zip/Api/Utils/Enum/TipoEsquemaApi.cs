﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoEsquemaApi
    {
        Create = 1,
        Read = 2,
        Update = 3,
        Delete = 4,
        Activate = 5
    }
    public static class TipoEsquemaApiExtension
    {
        public static string GetString(this TipoEsquemaApi _enum)
        {
            return _enum switch
            {
                TipoEsquemaApi.Create => "Create",
                TipoEsquemaApi.Read => "Read",
                TipoEsquemaApi.Update => "Update",
                TipoEsquemaApi.Delete => "Delete",
                TipoEsquemaApi.Activate => "Activate",
                _ => "No Válido",
            };
        }

        public static TipoMensajeRespuestaApi GetResponse(this TipoEsquemaApi _enum)
        {
            return _enum switch
            {
                TipoEsquemaApi.Create => TipoMensajeRespuestaApi.CreadoCorrectamente,
                TipoEsquemaApi.Read => TipoMensajeRespuestaApi.ListadoCorrectamente,
                TipoEsquemaApi.Update => TipoMensajeRespuestaApi.ActualizadoCorrectamente,
                TipoEsquemaApi.Delete => TipoMensajeRespuestaApi.EliminadoCorrectamente,
                TipoEsquemaApi.Activate => TipoMensajeRespuestaApi.ActivadoCorrectamente,
                _ => 0,
            };
        }
    }
}
