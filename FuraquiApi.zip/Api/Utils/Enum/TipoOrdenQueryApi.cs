﻿namespace Api.Utils.Enum
{
    public enum TipoOrdenQueryApi
    {
        Ascendente = 1, 
        Descendente = 2
    }
}
