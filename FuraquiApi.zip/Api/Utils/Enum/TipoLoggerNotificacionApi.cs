﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoLoggerNotificacionApi
    {
        Success = 1,
        Information = 2,
        Warning = 3,
        Error = 4
    }
    public static class TipoLoggerNotificacionApiExtension
    {
        public static string GetString(this TipoLoggerNotificacionApi _enum)
        {
            return _enum switch
            {
                TipoLoggerNotificacionApi.Success => "Success",
                TipoLoggerNotificacionApi.Information => "Information",
                TipoLoggerNotificacionApi.Warning => "Warning",
                TipoLoggerNotificacionApi.Error => "Error",
                _ => "No Válido",
            };
        }
    }
}
