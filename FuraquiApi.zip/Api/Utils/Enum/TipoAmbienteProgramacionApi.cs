﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoAmbienteProgramacionApi
    {
        Desarrollo = 1,
        Produccion = 2,
        Testing = 3
    }
    public static class TipoAmbienteProgramacionApiExtension
    {
        public static string GetString(this TipoAmbienteProgramacionApi _enum)
        {
            return _enum switch
            {
                TipoAmbienteProgramacionApi.Desarrollo => "Desarrollo",
                TipoAmbienteProgramacionApi.Produccion => "Produccion",
                TipoAmbienteProgramacionApi.Testing => "Testing",
                _ => "No Válido",
            };
        }
    }
}
