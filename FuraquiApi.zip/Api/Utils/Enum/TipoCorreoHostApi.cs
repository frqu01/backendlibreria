﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoCorreoHostApi
    {
        Outlook = 1,
        Gmail = 2
    }

    public static class TipoCorreoHostApiExtension
    {
        public static string GetHost(this TipoCorreoHostApi _enum)
        {
            return _enum switch
            {
                TipoCorreoHostApi.Outlook => "smtp.live.com",
                TipoCorreoHostApi.Gmail => "smtp.gmail.com",
                _ => throw new NotImplementedException()
            };
        }

        public static int GetPort(this TipoCorreoHostApi _enum)
        {
            return _enum switch
            {
                TipoCorreoHostApi.Outlook => 587,
                TipoCorreoHostApi.Gmail => 587,
                _ => throw new NotImplementedException()
            };
        }
    }
}
