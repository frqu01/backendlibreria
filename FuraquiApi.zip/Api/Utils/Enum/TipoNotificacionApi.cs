﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoNotificacionApi
    {
        Success = 1,
        Information = 2,
        Warning = 3,
        Error = 4
    }
    public static class TipoNotificacionApiExtension
    {
        public static string GetString(this TipoNotificacionApi _enum)
        {
            return _enum switch
            {
                TipoNotificacionApi.Success => "Respuesta Correcta.",
                TipoNotificacionApi.Information => "Respuesta Informativa.",
                TipoNotificacionApi.Warning => "Respuesta de Alerta.",
                TipoNotificacionApi.Error => "Respuesta con Error.",
                _ => "No Válido",
            };
        }
    }
}
