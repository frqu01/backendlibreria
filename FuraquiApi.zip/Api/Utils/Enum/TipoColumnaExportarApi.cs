﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoColumnaExportarApi
    {
        String = 1,
        Int32 = 2,
        Boolean = 3,
        Decimal = 4,
        Datetime = 5,
        Int64 = 6,
        Int16 = 7,
        Double = 8,
    }
    public static class TipoColumnaExportarApiExtension
    {
        public static string GetString(this TipoColumnaExportarApi _enum)
        {
            return _enum switch
            {
                TipoColumnaExportarApi.String => "String",
                TipoColumnaExportarApi.Int32 => "Int32",
                TipoColumnaExportarApi.Boolean => "Boolean",
                TipoColumnaExportarApi.Decimal => "Decimal",
                TipoColumnaExportarApi.Datetime => "Datetime",
                TipoColumnaExportarApi.Int64 => "Int64",
                TipoColumnaExportarApi.Int16 => "Int16",
                TipoColumnaExportarApi.Double => "Double",
                _ => "No Válido",
            };
        }

        public static TipoColumnaExportarApi GetEnumByName(string _name)
        {
            return _name switch
            {
                "String" => TipoColumnaExportarApi.String,
                "Int32" => TipoColumnaExportarApi.Int32,
                "Boolean" => TipoColumnaExportarApi.Boolean,
                "Decimal" => TipoColumnaExportarApi.Decimal,
                "Datetime" => TipoColumnaExportarApi.Datetime,
                "Int64" => TipoColumnaExportarApi.Int64,
                "Int16" => TipoColumnaExportarApi.Int16,
                "Double" => TipoColumnaExportarApi.Double,
                _ => throw new NotImplementedException()
            };
        }
    }
}
