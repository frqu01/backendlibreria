﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoKafkaTopicApi
    {
        Ninguno = 0,
        Usuario = 1,
        Persona = 2,
        Alcance = 3
    }
    public static class TipoKafkaTopicApiExtension
    {
        public static string GetString(this TipoKafkaTopicApi _enum)
        {
            return _enum switch
            {
                TipoKafkaTopicApi.Ninguno => "Ninguno",
                TipoKafkaTopicApi.Usuario => "KafkaUsuarioApi",
                TipoKafkaTopicApi.Persona=> "KafkaPersonaApi",
                TipoKafkaTopicApi.Alcance => "KafkaAlcanceApi",
                _ => "No Válido",
            };
        }
    }
}
