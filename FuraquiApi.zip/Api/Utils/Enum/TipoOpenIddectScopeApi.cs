﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoOpenIddectScopeApi
    {
        Create = 1,
        Read = 2,
        Update = 3,
        Delete = 4,
        Activate = 5
    }
    public static class TipoOpenIddectScopeApiExtension
    {
        public static string GetString(this TipoOpenIddectScopeApi _enum)
        {
            return _enum switch
            {
                TipoOpenIddectScopeApi.Create => "Crear",
                TipoOpenIddectScopeApi.Read => "Leer",
                TipoOpenIddectScopeApi.Update => "Actualizar",
                TipoOpenIddectScopeApi.Delete => "Eliminar",
                TipoOpenIddectScopeApi.Activate => "Activar",
                _ => "No Válido",
            };
        }
    }
}
