﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Utils.Enum
{
    public enum TipoLoggerMostradoApi
    {
        File = 1,
        Console = 2
    }
    public static class TipoLoggerMostradoApiExtension
    {
        public static string GetString(this TipoLoggerMostradoApi _enum)
        {
            return _enum switch
            {
                TipoLoggerMostradoApi.File => "file",
                TipoLoggerMostradoApi.Console => "console",
                _ => "No Válido",
            };
        }
    }
}
