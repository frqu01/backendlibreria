﻿using Api.Domains;
using System.Data.Common;

namespace Api.Infrastructures
{
    public interface IDbContextApi
    {
        DbCommand Connection<D>();
        Task<ResultadoApi> Create<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand);
        Task<ResultadoApi> Read<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand);
        Task<ResultadoApi> Update<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand);
        Task<ResultadoApi> Delete<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand);
        Task<ResultadoApi> Activate<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand);
    }
}
