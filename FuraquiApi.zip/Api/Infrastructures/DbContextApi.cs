﻿using Api.Domains;
using Api.Utils.Enum;
using Api.Utils.Interface;
using Api.Utils.Repository;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Collections;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data;
using System.Data.Common;

namespace Api.Infrastructures
{
    public class DbContextApi : IDbContextApi
    {
        protected readonly ILoggerApi _iLoggerApi;
        protected readonly IExceptionApi _iExceptionApi;
        protected readonly IFunctionApi _iFunctionApi;
        public DbContextApi()
        {
            _iLoggerApi = new LoggerApi();
            _iExceptionApi = new ExceptionApi();
            _iFunctionApi = new FunctionApi();
        }
        
        private async Task<ResultadoApi> StoreProcedure<T>(TipoEsquemaApi tipoEsquemaApi, ProcedimientoAlmacenadoApi procedimientoAlmacenadoApi)
        {
            //Validar
            if (procedimientoAlmacenadoApi == null)
            {
                throw _iExceptionApi.Warning("No se envió los datos del procedimiento almacenado a Infraestructura.");
            }

            var listaParametrosProcedimiento = ListaParametros(procedimientoAlmacenadoApi.Parametros);

            //Nombre del procedimiento almacenado
            string nombreProcedimientoCompleto = tipoEsquemaApi.GetString() + "." + procedimientoAlmacenadoApi.Nombre;

            //Validar entidad
            if (procedimientoAlmacenadoApi.Parametros == null)
            {
                throw _iExceptionApi.Warning("Los parámetos no fueron enviados a Infraestructura.");
            }

            //Validad id de usuario
            if (_iFunctionApi.ReflexionTipoDato(procedimientoAlmacenadoApi.Parametros, "RegistroUsuarioId") == null)
            {
                throw _iExceptionApi.Warning("El campo RegistroUsuarioId no esta en los parámetros en Infraestructura.");
            }

            if (procedimientoAlmacenadoApi.Parametros.RegistroUsuarioId == null)
            {
                throw _iExceptionApi.Warning("El campo RegistroUsuarioId fue enviado sin valor.");
            }

            //Validar id de empresa
            if (_iFunctionApi.ReflexionTipoDato(procedimientoAlmacenadoApi.Parametros, "RegistroEmpresaId") == null)
            {
                throw _iExceptionApi.Warning("El campo RegistroEmpresaId no esta en los parámetros en Infraestructura.");
            }

            if (procedimientoAlmacenadoApi.Parametros.RegistroEmpresaId == null)
            {
                throw _iExceptionApi.Warning("El campo RegistroEmpresaId fue enviado sin valor.");
            }

            //Ejecutar procedimiento almacenado 
            var sqlParametros = ListaParametros(procedimientoAlmacenadoApi.Parametros, listaParametrosProcedimiento);

            procedimientoAlmacenadoApi.DbCommand.Parameters.Clear();
            procedimientoAlmacenadoApi.DbCommand.CommandTimeout = 0;
            procedimientoAlmacenadoApi.DbCommand.CommandType = CommandType.StoredProcedure;
            procedimientoAlmacenadoApi.DbCommand.CommandText = nombreProcedimientoCompleto;
            procedimientoAlmacenadoApi.DbCommand.Parameters.AddRange(sqlParametros.ToArray());

            ResultadoApi resultadoApi = new();

            using (var dr = await procedimientoAlmacenadoApi.DbCommand.ExecuteReaderAsync())
            {
                MapeoBaseDatoApi<T> mapeoBaseDatoApi = LecturaBaseDatosApi<T>(dr);
                resultadoApi = new ResultadoApi()
                {
                    DatosApi = mapeoBaseDatoApi.Registros.ToList(),
                    EstadoSolicitudApi = new EstadoSolicitudApi()
                    {
                        EstaCorrecto = true,
                        MensajeRespuesta = MensajeRespuestaCorrecto(tipoEsquemaApi.GetResponse(), resultadoApi.DatosApi),
                        TipoNotificacionId = TipoNotificacionApi.Success,
                        CantidadDatos = mapeoBaseDatoApi.TotalRegistros
                    }
                };
            }

            return resultadoApi;
        }
        private static string MensajeRespuestaCorrecto(TipoMensajeRespuestaApi tipoRespuestaSolicitud, dynamic datosRespuestaApi)
        {
            string mensajeRespuestaCorrecto = tipoRespuestaSolicitud.GetString();

            if (datosRespuestaApi == null && tipoRespuestaSolicitud == TipoMensajeRespuestaApi.ListadoCorrectamente)
            {
                mensajeRespuestaCorrecto = "No se encontraron registros.";
            }
            else
            {
                if (datosRespuestaApi.GetType().IsGenericType)
                {
                    if (datosRespuestaApi.Count == 0 && tipoRespuestaSolicitud == TipoMensajeRespuestaApi.ListadoCorrectamente)
                    {
                        mensajeRespuestaCorrecto = "No se encontraron registros.";
                    }
                }
            }

            return mensajeRespuestaCorrecto;
        }
        private static object ValidarParametroParaBd(object valor)
        {
            if (valor == null || valor.ToString() == string.Empty || valor.ToString() == "-1")
            {
                return DBNull.Value;
            }
            else
            {
                dynamic valor_temp = Convert.ChangeType(valor, valor.GetType());

                if (valor_temp == null)
                {
                    return DBNull.Value;
                }
                else
                {
                    if (valor.GetType().Name == "String")
                    {
                        string valor_temp_trim = (string)valor_temp;
                        valor_temp = valor_temp_trim.Trim();
                    }

                    return valor_temp;
                }

            }
        }
        private static MapeoBaseDatoApi<T> LecturaBaseDatosApi<T>(DbDataReader dbDataReader)
        {
            MapeoBaseDatoApi<T> mapeoBaseDatosApi = new();
            var listaDatos = new List<T>();
            Type typeParameterType = typeof(T);

            switch (typeParameterType.FullName)
            {
                case "System.Int32":
                case "System.String":
                case "System.Decimal":
                case "System.Single":
                case "System.DateTime":
                case "System.Boolean":
                    int contadorRegistros = 0;
                    while (dbDataReader.Read())
                    {
                        T Entidad = (T)dbDataReader[0];
                        listaDatos.Add(Entidad);
                        contadorRegistros++;
                    }
                    mapeoBaseDatosApi.Registros = listaDatos;
                    mapeoBaseDatosApi.TotalRegistros = contadorRegistros;
                    break;
                default:
                    while (dbDataReader.Read())
                    {
                        var entidad = (T)Activator.CreateInstance(typeof(T));

                        for (int i = 0; i < dbDataReader.FieldCount; i++)
                        {
                            string rowName = dbDataReader.GetName(i);
                            foreach (var prop in typeof(T).GetProperties())
                            {
                                // 1). If entity reference, bypass it.
                                if (prop.PropertyType.Namespace == typeof(T).Namespace)
                                {
                                    continue;
                                }
                                // 2). If collection, bypass it.
                                if (prop.PropertyType != typeof(string) && typeof(IEnumerable).IsAssignableFrom(prop.PropertyType))
                                {
                                    continue;
                                }
                                // 3). If property is NotMapped, bypass it.
                                if (Attribute.IsDefined(prop, typeof(NotMappedAttribute)))
                                {
                                    continue;
                                }

                                if (prop.Name == rowName)
                                {
                                    var dbValue = dbDataReader[prop.Name];
                                    if (dbValue is DBNull) continue;
                                    if (prop.PropertyType.IsConstructedGenericType &&
                                        prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                                    {
                                        var baseType = prop.PropertyType.GetGenericArguments()[0];
                                        var baseValue = Convert.ChangeType(dbValue, baseType);
                                        var value = Activator.CreateInstance(prop.PropertyType, baseValue);

                                        if (prop.Name == "TotalRegistros")
                                        {
                                            mapeoBaseDatosApi.TotalRegistros = int.Parse(value.ToString());
                                            value = null;
                                        }

                                        prop.SetValue(entidad, value);

                                        break;
                                    }
                                    else
                                    {
                                        var value = Convert.ChangeType(dbValue, prop.PropertyType);

                                        if (prop.Name == "TotalRegistros")
                                        {
                                            mapeoBaseDatosApi.TotalRegistros = int.Parse(value.ToString());
                                            value = null;
                                        }

                                        prop.SetValue(entidad, value);

                                        break;
                                    }
                                }
                            }
                        }

                        listaDatos.Add(entidad);
                    }

                    if (mapeoBaseDatosApi.TotalRegistros == null)
                    {
                        mapeoBaseDatosApi.TotalRegistros = listaDatos.Count;
                    }
                    mapeoBaseDatosApi.Registros = listaDatos;
                    break;
            }

            return mapeoBaseDatosApi;
        }
        private List<string> ListaParametros(dynamic obj)
        {
            List<string> vs = new();

            foreach (var propiedad in obj.GetType().GetProperties())
            {
                var name = "@" + propiedad.Name;
                var type = _iFunctionApi.ReflexionTipoDato(obj, propiedad.Name);

                switch (type)
                {
                    case "Int32":
                    case "Int64":
                    case "String":
                    case "Decimal":
                    case "Single":
                    case "DateTime":
                    case "Boolean":
                        vs.Add(name);
                        break;
                    default:
                        break;
                }
            }

            return vs;
        }
        private List<SqlParameter> ListaParametros(dynamic obj, List<string> parametros)
        {
            var resultadoSqlParameter = new List<SqlParameter>();

            foreach (var parametro in parametros)
            {
                SqlParameter param = new();

                param.ParameterName = parametro;
                if (obj.GetType().GetProperty(parametro[1..]) == null) //parametro.Substring(1, parametro.Length - 1)
                {
                    foreach (var propiedad in obj.GetType().GetProperties())
                    {
                        var clase = obj.GetType().GetProperty(propiedad.Name).GetValue(obj, null);
                        if (clase != null && clase.GetType().GetProperty(parametro[1..]) != null)
                        {
                            param.Value = ValidarParametroParaBd(clase.GetType().GetProperty(parametro[1..]).GetValue(clase, null));
                        }
                    }
                }
                else
                {
                    param.Value = ValidarParametroParaBd(obj.GetType().GetProperty(parametro[1..]).GetValue(obj, null));
                }

                resultadoSqlParameter.Add(param);
            }

            return resultadoSqlParameter;
        }
        private string ParametrosSqlConcatenados(List<SqlParameter> sqlParameters)
        {
            string cadenaValores = string.Empty;

            if (sqlParameters.Count > 0)
            {
                foreach (var parametro in sqlParameters)
                {
                    cadenaValores = cadenaValores + parametro.ParameterName + " = " + (parametro.Value == null ? "" : parametro.Value.ToString()) + ", ";
                }

                cadenaValores = cadenaValores[0..^2]; //cadenaValores.Substring(0, cadenaValores.Length - 2);
            }

            return cadenaValores;
        }

        public DbCommand Connection<D>()
        {
            DbContext dbContext = (DbContext)Activator.CreateInstance(typeof(D));
            //Validar
            if (dbContext == null)
            {
                throw _iExceptionApi.Warning("La Conexión no fue enviada en Infraestructura.");
            }
            DbCommand dbCommand = dbContext.Database.GetDbConnection().CreateCommand();
            var conn = new ConnectionApi(dbCommand);
            return conn.Open();
        }

        public async Task<ResultadoApi> Create<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand)
        {
            return await StoreProcedure<T>(TipoEsquemaApi.Create, new ()
            {
                Nombre = storeProcedureName,
                Parametros = Parameters,
                DbCommand = dbCommand
            });
        }

        public async Task<ResultadoApi> Read<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand)
        {
            return await StoreProcedure<T>(TipoEsquemaApi.Read, new()
            {
                Nombre = storeProcedureName,
                Parametros = Parameters,
                DbCommand = dbCommand
            });
        }

        public async Task<ResultadoApi> Update<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand)
        {
            return await StoreProcedure<T>(TipoEsquemaApi.Update, new()
            {
                Nombre = storeProcedureName,
                Parametros = Parameters,
                DbCommand = dbCommand
            });
        }

        public async Task<ResultadoApi> Delete<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand)
        {
            return await StoreProcedure<T>(TipoEsquemaApi.Delete, new()
            {
                Nombre = storeProcedureName,
                Parametros = Parameters,
                DbCommand = dbCommand
            });
        }

        public async Task<ResultadoApi> Activate<T>(string storeProcedureName, dynamic Parameters, DbCommand dbCommand)
        {
            return await StoreProcedure<T>(TipoEsquemaApi.Activate, new()
            {
                Nombre = storeProcedureName,
                Parametros = Parameters,
                DbCommand = dbCommand
            });
        }
    }
}
