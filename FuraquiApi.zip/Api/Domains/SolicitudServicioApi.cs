﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class SolicitudServicioApi
    {
        public string HostUrl { get; set; }
        public string MetodoUrl { get; set; }
        public dynamic Entidad { get; set; }
        public HttpMethod TipoMetodoRest { get; set; }
        public bool EsResultadoApi { get; set; }
    }
}
