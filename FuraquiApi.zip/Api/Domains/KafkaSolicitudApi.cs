﻿using Api.Utils.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class KafkaSolicitudApi
    {
        public Guid KafkaSolicitudApiId { get; set; }
        public TipoKafkaEventoApi TipoKafkaEventoApi { get; set; }
        public TipoKafkaTopicApi TipoKafkaTopicApi { get; set; }
        public DateTime Fecha { get; set; } = DateTime.Now;
        public string Entidad { get; set; }
    }
}
