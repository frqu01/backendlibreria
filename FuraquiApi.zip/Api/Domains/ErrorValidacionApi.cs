﻿namespace Api.Domains
{
    public class ErrorValidacionApi
    {
        public string Entidad { get; set; }
        public string Campo { get; set; }
        public string Mensaje { get; set; }
    }
}
