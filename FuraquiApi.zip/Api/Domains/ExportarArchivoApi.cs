﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class ExportarArchivoApi
    {
        public byte[] Contenido { get; set; }
        public string Nombre { get; set; }
        public string Tipo { get; set; }
    }
}
