﻿namespace Api.Domains
{
    public class MapeoBaseDatoApi<T>
    {
        public List<T> Registros { get; set; }
        public int? TotalRegistros { get; set; }
    }
}
