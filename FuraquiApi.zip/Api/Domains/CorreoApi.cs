﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class CorreoApi
    {
        public string Emisor { get; set; }
        public string Contrasena { get; set; }
        public List<string> Respuesta { get; set; }
        public List<string> Receptor { get; set; }
        public List<string> Copia { get; set; }
        public List<string> CopiaOculta { get; set; }
        public string Asunto { get; set; }
        public string Cuerpo{ get; set; }
        public List<CorreoAdjuntoApi> CorreoAdjuntoApi { get; set; }
    }
}
