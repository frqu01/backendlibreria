﻿using Api.Utils.Enum;
using System.ComponentModel;

namespace Api.Domains
{
    public class ResultadoApi
    {
        [DefaultValue(null)]
        public dynamic DatosApi { get; set; }
        [DefaultValue(null)]
        public EstadoSolicitudApi EstadoSolicitudApi { get; set; }
        public List<ErrorValidacionApi> ErroresValidacionApi { get; set; }
        public bool Status()
        {
            if (EstadoSolicitudApi == null)
            {
                return false;
            }

            return EstadoSolicitudApi.EstaCorrecto;
        }
    }
}
