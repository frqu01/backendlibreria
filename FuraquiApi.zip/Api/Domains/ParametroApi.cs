﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class ParametroApi
    {
        public long RegistroApiUsuarioId { get; set; }
        public int RegistroApiEmpresaId { get; set; }
    }
    #region Validaciones
    public class ParametroApiValidator : AbstractValidator<ParametroApi>
    {
        public ParametroApiValidator()
        {
            #region Validaciones del caso de uso
            RuleFor(t => t.RegistroApiUsuarioId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(x => x > 0);
            RuleFor(t => t.RegistroApiEmpresaId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(x => x > 0);
            #endregion
        }
    }
    #endregion
}
