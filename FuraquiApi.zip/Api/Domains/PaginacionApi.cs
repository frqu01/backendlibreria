﻿using Api.Utils;
using Api.Utils.Enum;
using FluentValidation;

namespace Api.Domains
{
    public class PaginacionApi
    {
        public int PaginaActual { get; set; } = 0;
        public int RegistrosPorPagina { get; set; } = GlobalApi.CantidadRegistrosMaximo;
        public string OrdenarPorCampo { get; set; }
        public string OrdenarPorDireccion { get; set; }
        public long RegistroApiUsuarioId { get; set; }
        public int RegistroApiEmpresaId { get; set; }
    }
    #region Validaciones
    public class PaginacionApiValidator : AbstractValidator<PaginacionApi>
    {
        public PaginacionApiValidator()
        {
            #region Validaciones del caso de uso
            RuleFor(t => t.RegistroApiUsuarioId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(x => x > 0);
            RuleFor(t => t.RegistroApiEmpresaId).Cascade(CascadeMode.Stop).NotNull().NotEmpty().Must(x => x > 0);
            #endregion
        }
    }
    #endregion
}
