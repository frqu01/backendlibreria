﻿using Api.Utils.Enum;
using System.Data.Common;

namespace Api.Domains
{
    public class ProcedimientoAlmacenadoApi
    {
        public string Nombre { get; set; }
        public dynamic Parametros { get; set; }
        public DbCommand DbCommand { get; set; }
    }
}
