﻿using Api.Utils.Enum;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Domains
{
    public class CorreoAdjuntoApi
    {
        public MemoryStream AdjuntoStream { get; set; }
        public string Nombre { get; set; }
        public TipoExtensionArchivoApi TipoExtensionArchivo { get; set; }
    }
}
