﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Api.Domains
{
    public class RegistroApi
    {        
        [Required]
        [Column("RegistroApiUsuarioId", TypeName = "bigint")]
        public long RegistroApiUsuarioId { get; set; }
        [Required]
        public int RegistroApiEmpresaId { get; set; }
        [Required]
        public bool RegistroApiEstado { get; set; } = true;
        [Required]
        [Column("RegistroApiFecha", TypeName = "DateTime")]
        public DateTime RegistroApiFecha { get; set; } = DateTime.Now;
    }
}
