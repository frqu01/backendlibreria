﻿using Api.Utils.Enum;
using System.ComponentModel;

namespace Api.Domains
{
    public class EstadoSolicitudApi
    {
        private string mensajeRespuesta;
        private string mensajeRespuestaDetalle;
        public int? CantidadDatos { get; set; } = null;
        [DefaultValue(false)]
        public bool EstaCorrecto { get; set; }
        public string MensajeRespuesta
        {
            get
            {
                return mensajeRespuesta;
            }
            set
            {
                mensajeRespuesta = value == null || value == string.Empty ? value : value.Substring(value.Length - 1) != "." ? value + "." : value;
            }
        }
        public TipoNotificacionApi TipoNotificacionId { get; set; }
        public string MensajeRespuestaDetalle
        {
            get
            {
                return mensajeRespuestaDetalle;
            }
            set
            {
                mensajeRespuestaDetalle = value == null || value == string.Empty ? value : value.Substring(value.Length - 1) != "." ? value + "." : value;
            }
        }
    }
}
