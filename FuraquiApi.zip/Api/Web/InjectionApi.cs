﻿using Api.Utils.Interface;
using Api.Utils.Repository;
using Microsoft.Extensions.DependencyInjection;

namespace Api.Web
{
    public static class InjectionApi
    {
        public static void Init(IServiceCollection iServiceCollection)
        {
            iServiceCollection.AddTransient<IStartupApi, StartupApi>();
            iServiceCollection.AddTransient<IHandlerExceptionApi, HandlerExceptionApi>();
        }
    }
}
