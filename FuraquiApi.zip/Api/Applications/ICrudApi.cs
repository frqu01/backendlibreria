﻿using Api.Domains;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Api.Applications
{
    public interface ICrudApi
    {
        Task<ResultadoApi> Crear(dynamic request);
        Task<ResultadoApi> Actualizar(dynamic request);
        Task<ResultadoApi> Eliminar(dynamic request);
        Task<ResultadoApi> Activar(dynamic request);
        Task<ResultadoApi> Leer(dynamic request);
        Task<ResultadoApi> LeerPorId(dynamic request);
    }
}
